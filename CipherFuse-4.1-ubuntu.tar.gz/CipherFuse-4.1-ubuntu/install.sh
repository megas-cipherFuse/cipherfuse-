#!/usr/bin/env bash
# Install CipherFuse on Ubuntu / Debian and pull in the libraries it needs.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
APP_SRC="$ROOT/app"
PREFIX="/opt/cipherfuse"

if ! command -v apt-get >/dev/null 2>&1; then
  echo "This installer is for Ubuntu and Debian (apt)."
  echo "See PREREQUISITES.txt if you are on another distribution."
  exit 1
fi

echo "Installing prerequisites: Python 3, PyQt6, and the serial library..."
sudo apt-get update
sudo apt-get install -y \
  python3 \
  python3-pip \
  python3-venv \
  python3-pyqt6 \
  python3-serial

echo "Copying CipherFuse to $PREFIX ..."
sudo mkdir -p "$PREFIX"
sudo cp -a "$APP_SRC/." "$PREFIX/"

echo "Installing esptool support libraries into a local environment..."
sudo python3 -m venv --system-site-packages "$PREFIX/venv"
if compgen -G "$ROOT/wheels/*.whl" > /dev/null; then
  sudo "$PREFIX/venv/bin/pip" install --upgrade pip
  if ! sudo "$PREFIX/venv/bin/pip" install --no-index --find-links "$ROOT/wheels" \
      -r "$PREFIX/requirements-runtime.txt"; then
    echo "Bundled wheels did not match this Python. Downloading the libraries..."
    sudo "$PREFIX/venv/bin/pip" install -r "$PREFIX/requirements-runtime.txt"
  fi
else
  sudo "$PREFIX/venv/bin/pip" install --upgrade pip
  sudo "$PREFIX/venv/bin/pip" install -r "$PREFIX/requirements-runtime.txt"
fi

sudo tee /usr/local/bin/cipherfuse >/dev/null <<'EOF'
#!/bin/sh
exec /opt/cipherfuse/venv/bin/python /opt/cipherfuse/esp32_flash_encrypt_qt_v3.py "$@"
EOF
sudo chmod 755 /usr/local/bin/cipherfuse

if [ -d /usr/share/applications ]; then
  sudo cp "$ROOT/cipherfuse.desktop" /usr/share/applications/cipherfuse.desktop
fi

echo
echo "CipherFuse is installed."
echo "Start it from the app menu, or run: cipherfuse"
