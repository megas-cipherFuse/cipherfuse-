#!/usr/bin/env python3
"""
Shared core logic for ESP32-S2 Flash Encryption Tool v3.
"""

import hashlib
import os
import secrets
import struct
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

VERSION = "4.1"
APP_NAME = "CipherFuse"
COMPANY = "CipherFuse"
TAGLINE = "Flash encryption for ESP32 boards"
PROJECT_URL = "https://cipherfuse.dev"
DONATE_URL = "https://cipherfuse.dev/#donate"
# Not affiliated with Espressif. ESP32 is a trademark of Espressif Systems.

# --- Multi-chip support -----------------------------------------------------
# Each ESP target differs in: bootloader offset, flash-encryption scheme,
# eFuse key block / key purpose, and the eFuse that enables encryption.
#
# scheme:
#   "xts"   -> newer chips (S2/S3/C3/C6/H2/...): espsecure --aes-xts,
#              espefuse burn-key BLOCK_KEYx <key> XTS_AES_128_KEY,
#              enabled via SPI_BOOT_CRYPT_CNT.
#   "esp32" -> original ESP32: AES-256 ECB scheme with FLASH_CRYPT_CONFIG,
#              espefuse burn-key flash_encryption <key> (BLOCK1),
#              enabled via FLASH_CRYPT_CNT.
CHIP_PROFILES = {
    "esp32": {
        "label": "ESP32 (classic)",
        "bootloader_addr": 0x1000,
        "scheme": "esp32",
        "key_block": "flash_encryption",
        "key_purpose": None,
        "crypt_cnt_efuse": "FLASH_CRYPT_CNT",
        "flash_crypt_config": 0xF,
    },
    "esp32s2": {
        "label": "ESP32-S2",
        "bootloader_addr": 0x1000,
        "scheme": "xts",
        "key_block": "BLOCK_KEY0",
        "key_purpose": "XTS_AES_128_KEY",
        "crypt_cnt_efuse": "SPI_BOOT_CRYPT_CNT",
    },
    "esp32s3": {
        "label": "ESP32-S3",
        "bootloader_addr": 0x0,
        "scheme": "xts",
        "key_block": "BLOCK_KEY0",
        "key_purpose": "XTS_AES_128_KEY",
        "crypt_cnt_efuse": "SPI_BOOT_CRYPT_CNT",
    },
    "esp32c2": {
        "label": "ESP32-C2 (ESP8684)",
        "bootloader_addr": 0x0,
        "scheme": "xts",
        "key_block": "BLOCK_KEY0",
        "key_purpose": "XTS_AES_128_KEY",
        "crypt_cnt_efuse": "SPI_BOOT_CRYPT_CNT",
    },
    "esp32c3": {
        "label": "ESP32-C3",
        "bootloader_addr": 0x0,
        "scheme": "xts",
        "key_block": "BLOCK_KEY0",
        "key_purpose": "XTS_AES_128_KEY",
        "crypt_cnt_efuse": "SPI_BOOT_CRYPT_CNT",
    },
    "esp32c6": {
        "label": "ESP32-C6",
        "bootloader_addr": 0x0,
        "scheme": "xts",
        "key_block": "BLOCK_KEY0",
        "key_purpose": "XTS_AES_128_KEY",
        "crypt_cnt_efuse": "SPI_BOOT_CRYPT_CNT",
    },
    "esp32h2": {
        "label": "ESP32-H2",
        "bootloader_addr": 0x0,
        "scheme": "xts",
        "key_block": "BLOCK_KEY0",
        "key_purpose": "XTS_AES_128_KEY",
        "crypt_cnt_efuse": "SPI_BOOT_CRYPT_CNT",
    },
    "esp32p4": {
        "label": "ESP32-P4",
        "bootloader_addr": 0x2000,
        "scheme": "xts",
        "key_block": "BLOCK_KEY0",
        "key_purpose": "XTS_AES_128_KEY",
        "crypt_cnt_efuse": "SPI_BOOT_CRYPT_CNT",
    },
}

DEFAULT_CHIP = "esp32s2"
# Backward-compatible alias (older code/tests referenced module-level CHIP).
CHIP = DEFAULT_CHIP


def chip_profile(chip=None):
    """Return the profile dict for a chip id (falls back to the default chip)."""
    return CHIP_PROFILES.get((chip or DEFAULT_CHIP).lower(), CHIP_PROFILES[DEFAULT_CHIP])


def chip_choices():
    """Ordered list of (chip_id, label) for UI dropdowns."""
    return [(cid, prof["label"]) for cid, prof in CHIP_PROFILES.items()]


def bootloader_addr(chip=None):
    """Bootloader flash offset for the given chip (0x0/0x1000/0x2000)."""
    return chip_profile(chip)["bootloader_addr"]


# Default 115200 = no baud-rate change after connect. Critical for ESP32-S2/S3 in
# USB-OTG (native USB-CDC) mode: changing baud makes the USB device re-enumerate,
# which kills the COM port mid-flash (OSError 22 "device does not exist").
# Over native USB the baud is virtual, so 115200 is just as fast as 921600.
DEFAULT_FLASH_BAUD = 115200

# Partition table / OTA data / app offsets are defined by the partition table and
# are identical across chips for the standard Arduino layout. Only the bootloader
# offset is chip-specific (see CHIP_PROFILES).
ADDR_BOOTLOADER = 0x1000  # legacy default (ESP32 / ESP32-S2); use bootloader_addr(chip)
ADDR_PARTITION = 0x8000
ADDR_OTADATA = 0xE000
ADDR_APP = 0x10000

PROJECT_DIR = Path(__file__).resolve().parent
BUNDLED_TOOL_DIR = PROJECT_DIR / "esptool"

ARDUINO_HINT = (
    "Arduino firmware — flash all four binaries:\n"
    "     • Sketch.ino.bootloader.bin  @ 0x1000\n"
    "     • Sketch.ino.partitions.bin  @ 0x8000\n"
    "     • boot_app0.bin              @ 0xE000  (required when otadata partition exists)\n"
    "     • Sketch.ino.bin             @ 0x10000\n"
    "Before 'Flash & Encrypt': generate key → burn key to eFuse (or let the tool auto-burn)."
)


def _estimate_flash_minutes(images, encrypt_on_device=False):
    """Rough ETA for UI messaging only — flash commands do not time out."""
    total = sum(os.path.getsize(path) for _, path, _ in images if os.path.isfile(path))
    seconds = 120 + total // 12000
    if encrypt_on_device:
        seconds = int(seconds * 2.0)
    return max(2, (seconds + 59) // 60)


def _encrypt_timeout_seconds(input_path):
    """Offline espsecure timeout scales with file size (no upper cap)."""
    size = os.path.getsize(input_path) if os.path.isfile(input_path) else 0
    return max(300, 120 + size // 4000)


def _tool_env(custom_path=None):
    """Build PYTHONPATH so bundled esptool/espefuse modules resolve."""
    env = os.environ.copy()
    dirs = [str(BUNDLED_TOOL_DIR)]

    if custom_path:
        path = Path(custom_path).resolve()
        if path.is_file():
            dirs.insert(0, str(path.parent))
        elif path.is_dir():
            dirs.insert(0, str(path))

    existing = env.get("PYTHONPATH", "")
    combined = os.pathsep.join(dict.fromkeys(dirs))
    env["PYTHONPATH"] = combined + (os.pathsep + existing if existing else "")
    return env


# When running as a PyInstaller-frozen .exe, `sys.executable` is our own GUI exe
# (not a Python interpreter), so `python -m esptool` cannot work. Instead we re-exec
# our own frozen binary with a `--run-tool=<name>` sentinel; main() dispatches it to
# the bundled esptool/espefuse/espsecure ._main() before the GUI starts.
FROZEN = bool(getattr(sys, "frozen", False))


def _build_tool_cmd(tool, args, custom_path=None):
    if FROZEN:
        # Modules are collected into the frozen app; no PYTHONPATH juggling needed.
        return [sys.executable, f"--run-tool={tool}", *args], os.environ.copy()
    return [sys.executable, "-m", tool, *args], _tool_env(custom_path)


def build_esptool_cmd(*args, esptool_path=None):
    """Build an `esptool` command (python -m in dev, re-exec when frozen)."""
    return _build_tool_cmd("esptool", args, esptool_path)


def build_espsecure_cmd(*args, esptool_path=None):
    """Build an `espsecure` command (python -m in dev, re-exec when frozen)."""
    return _build_tool_cmd("espsecure", args, esptool_path)


def build_espefuse_cmd(*args, espefuse_path=None):
    """Build an `espefuse` command (python -m in dev, re-exec when frozen)."""
    return _build_tool_cmd("espefuse", args, espefuse_path)


def find_tool(name, custom_path=None):
    """Resolve tool location — returns bundled tool dir by default."""
    if custom_path:
        path = Path(custom_path)
        if path.is_file():
            return str(path.parent)
        if path.is_dir():
            return str(path)

    if BUNDLED_TOOL_DIR.is_dir():
        return str(BUNDLED_TOOL_DIR)

    idf = os.environ.get("IDF_PATH")
    if idf:
        if "esptool" in name:
            candidate = os.path.join(idf, "components", "esptool_py", "esptool")
        else:
            candidate = os.path.join(idf, "components", "espefuse", "pyespefuse")
        if os.path.isdir(candidate):
            return candidate

    return str(BUNDLED_TOOL_DIR)


def _should_log_line(line):
    """Skip deprecation noise and empty lines."""
    if not line.strip():
        return False
    if "DEPRECATED" in line.upper():
        return False
    return True


def run_cmd(cmd, log_fn=None, timeout=180, env=None, stream=False):
    """Execute a command. Use stream=True for long esptool flashes (no timeout cap)."""
    try:
        if stream:
            return _run_cmd_streamed(cmd, log_fn, timeout, env)

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env or os.environ.copy(),
        )

        if log_fn:
            for line in result.stdout.strip().split("\n"):
                if _should_log_line(line):
                    log_fn(line.strip())
            if result.returncode != 0:
                for line in result.stderr.strip().split("\n"):
                    if _should_log_line(line):
                        log_fn(f"ERROR: {line.strip()}")

        return result.returncode == 0, result
    except subprocess.TimeoutExpired:
        if log_fn:
            log_fn(f"ERROR: Command timed out ({timeout}s limit)")
        return False, None
    except PermissionError as exc:
        if log_fn:
            log_fn(f"ERROR: Permission denied: {exc}")
            log_fn(
                "  If this is a COM port: close Arduino Serial Monitor / PuTTY / "
                "other tools using that port, then retry."
            )
        return False, None
    except Exception as exc:
        if log_fn:
            log_fn(f"ERROR: {exc}")
        return False, None


def _run_cmd_streamed(cmd, log_fn, timeout, env):
    """
    Run esptool with live stdout — avoids GUI appearing frozen during long flashes.
    timeout=None waits until esptool exits (recommended for write-flash --encrypt).
    """
    env = env or os.environ.copy()
    start = time.monotonic()
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=env,
        errors="replace",
    )

    if proc.stdout is None:
        return False, None

    collected = []
    while True:
        if timeout is not None and time.monotonic() - start > timeout:
            proc.kill()
            proc.wait()
            if log_fn:
                log_fn(f"ERROR: Command timed out ({timeout}s limit)")
            return False, None

        line = proc.stdout.readline()
        if line == "" and proc.poll() is not None:
            break
        if not line:
            continue

        line = line.rstrip("\r\n")
        if line:
            collected.append(line)
            if log_fn and _should_log_line(line):
                log_fn(line.strip())

    code = proc.wait()
    if code != 0 and log_fn:
        log_fn(f"ERROR: esptool exited with code {code}")

    result = subprocess.CompletedProcess(cmd, code, "\n".join(collected), "")
    return code == 0, result


def default_key_path():
    """
    Writable default key location (user Documents, not Program Files / CWD).
    Avoids Permission denied when the app is installed per-machine via MSI.
    """
    docs = Path.home() / "Documents" / "CipherFuse"
    docs.mkdir(parents=True, exist_ok=True)
    return str(docs / "flash_encryption_key.bin")


def ensure_writable_key_path(path=None, log_fn=None):
    """
    Resolve a key output path that we can actually write.
    - If the path is a folder, append flash_encryption_key.bin.
    - Relative / protected folders fall back to Documents.
    """
    if not path:
        return default_key_path()

    preferred = Path(str(path).strip().rstrip("/\\")).expanduser()

    # User pointed at a folder (exists as dir, or path ends with separator).
    # Opening a directory with open(..., "wb") raises PermissionError on Windows.
    if preferred.is_dir() or str(path).rstrip().endswith(("/", "\\")):
        preferred = preferred / "flash_encryption_key.bin"
        if log_fn:
            log_fn(f"Key path is a folder — writing file: {preferred}")
    elif preferred.suffix.lower() not in (".bin", ".key"):
        # e.g. "...\bps_firmware_keys" with no extension — treat as folder intent.
        preferred = preferred / "flash_encryption_key.bin"
        if log_fn:
            log_fn(f"No .bin extension — treating as folder: {preferred}")

    if not preferred.is_absolute():
        preferred = Path.cwd() / preferred

    def _can_write(target: Path) -> bool:
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            probe = target.parent / ".cipherfuse_write_probe"
            with open(probe, "wb") as handle:
                handle.write(b"ok")
            probe.unlink(missing_ok=True)
            return True
        except OSError:
            return False

    if _can_write(preferred):
        return str(preferred)

    fallback = Path(default_key_path())
    if log_fn:
        log_fn(f"WARNING: Cannot write to: {preferred}")
        log_fn(f"  Using writable location instead: {fallback}")
    return str(fallback)


def generate_key_file(output_path, log_fn=None):
    """Generate a 256-bit flash encryption key."""
    output_path = ensure_writable_key_path(output_path, log_fn=log_fn)
    key = secrets.token_bytes(32)
    out = Path(output_path)
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, "wb") as handle:
            handle.write(key)
    except PermissionError:
        if log_fn:
            log_fn(f"ERROR: Permission denied writing key to: {output_path}")
            log_fn("  Pick a writable folder (e.g. Documents), not Program Files.")
            log_fn(f"  Suggested path: {default_key_path()}")
        raise

    if log_fn:
        log_fn(f"Key file: {out}")
        log_fn(f"Key size: {len(key)} bytes (256-bit AES-256)")
        log_fn(f"SHA-256: {hashlib.sha256(key).hexdigest()}")
        log_fn("WARNING: Backup this key immediately!")
        log_fn("Without this key, firmware updates are impossible!")

    return str(out)


def burn_key_to_efuse(key_file, port, log_fn=None, espefuse_path=None,
                      uart_disable=False, jtag_disable=False, chip=None):
    """Burn encryption key and enable flash encryption for the selected chip."""
    if not os.path.isfile(key_file):
        if log_fn:
            log_fn(f"ERROR: Key not found: {key_file}")
        return False

    prof = chip_profile(chip)
    chip_id = (chip or DEFAULT_CHIP).lower()

    # --do-not-confirm: espefuse otherwise waits for an interactive "BURN" prompt,
    # which hangs (and times out) when stdin is captured by the GUI/CLI.
    if prof["scheme"] == "esp32":
        # Original ESP32: 256-bit key in BLOCK1, no key purpose.
        if log_fn:
            log_fn("Burning encryption key to BLOCK1 (flash_encryption)...")
        cmd, env = build_espefuse_cmd(
            "--chip", chip_id, "-p", port, "--do-not-confirm",
            "burn-key", prof["key_block"], key_file,
            espefuse_path=espefuse_path,
        )
    else:
        if log_fn:
            log_fn(f"Burning encryption key to {prof['key_block']} ({prof['key_purpose']})...")
        cmd, env = build_espefuse_cmd(
            "--chip", chip_id, "-p", port, "--do-not-confirm",
            "burn-key", prof["key_block"], key_file, prof["key_purpose"],
            espefuse_path=espefuse_path,
        )
    success, _ = run_cmd(cmd, log_fn, env=env, timeout=120)
    if not success:
        return False

    crypt_efuse = prof["crypt_cnt_efuse"]
    if log_fn:
        log_fn(f"Enabling flash encryption ({crypt_efuse})...")

    cmd, env = build_espefuse_cmd(
        "--chip", chip_id, "-p", port, "--do-not-confirm",
        "burn-efuse", crypt_efuse, "1",
        espefuse_path=espefuse_path,
    )
    success, _ = run_cmd(cmd, log_fn, env=env, timeout=120)
    if not success:
        return False

    # Original ESP32 also needs FLASH_CRYPT_CONFIG set (tweak/range bits).
    if prof["scheme"] == "esp32":
        if log_fn:
            log_fn("Setting FLASH_CRYPT_CONFIG=0xF (ESP32)...")
        cmd, env = build_espefuse_cmd(
            "--chip", chip_id, "-p", port, "--do-not-confirm",
            "burn-efuse", "FLASH_CRYPT_CONFIG", str(prof["flash_crypt_config"]),
            espefuse_path=espefuse_path,
        )
        success, _ = run_cmd(cmd, log_fn, env=env, timeout=120)
        if not success:
            return False

    if uart_disable:
        if log_fn:
            log_fn("Enabling DIS_DOWNLOAD_MODE (UART download disable)...")
        cmd, env = build_espefuse_cmd(
            "--chip", chip_id, "-p", port, "--do-not-confirm",
            "burn-efuse", "DIS_DOWNLOAD_MODE", "1",
            espefuse_path=espefuse_path,
        )
        run_cmd(cmd, log_fn, env=env, timeout=120)

    if jtag_disable:
        if log_fn:
            log_fn("Enabling HARD_DIS_JTAG...")
        cmd, env = build_espefuse_cmd(
            "--chip", chip_id, "-p", port, "--do-not-confirm",
            "burn-efuse", "HARD_DIS_JTAG", "1",
            espefuse_path=espefuse_path,
        )
        run_cmd(cmd, log_fn, env=env, timeout=120)

    if log_fn:
        log_fn("SUCCESS: Flash encryption enabled!")
    return True


def encrypt_file(key_file, input_path, address, output_path=None, log_fn=None,
                 esptool_path=None, chip=None):
    """Encrypt a single binary file offline (creates .enc.bin backup)."""
    if not os.path.isfile(key_file):
        if log_fn:
            log_fn(f"ERROR: Key not found: {key_file}")
        return None

    if not os.path.isfile(input_path):
        if log_fn:
            log_fn(f"WARNING: File not found: {input_path}")
        return None

    if output_path is None:
        output_path = input_path.replace(".bin", ".enc.bin")

    if log_fn:
        log_fn(f"  Input:  {input_path}")
        log_fn(f"  Output: {output_path}")
        log_fn(f"  Address: {hex(address)}")

    prof = chip_profile(chip)
    scheme_args = (
        ["--aes-xts"] if prof["scheme"] == "xts"
        else ["--flash-crypt-conf", hex(prof["flash_crypt_config"])]
    )
    cmd, env = build_espsecure_cmd(
        "encrypt-flash-data",
        "--keyfile", key_file,
        "--address", hex(address),
        "--output", output_path,
        *scheme_args,
        input_path,
        esptool_path=esptool_path,
    )
    success, _ = run_cmd(
        cmd, log_fn, env=env,
        timeout=_encrypt_timeout_seconds(input_path),
        stream=os.path.getsize(input_path) > 512 * 1024,
    )
    if success:
        if log_fn:
            log_fn(f"  -> Created: {output_path}")
        return output_path
    return None


def partition_has_otadata(partition_path):
    """Return True if the partition table defines an otadata region (needs boot_app0.bin)."""
    if not partition_path or not os.path.isfile(partition_path):
        return False
    data = Path(partition_path).read_bytes()
    for i in range(0, len(data) - 31, 32):
        chunk = data[i:i + 32]
        magic, ptype, subtype, offset, _size, label, _flags = struct.unpack(
            "<HBBII16sI", chunk,
        )
        if magic != 0x50AA:
            break
        name = label.split(b"\x00")[0].decode("ascii", errors="replace")
        if name == "otadata" or (ptype == 1 and subtype == 0 and offset == ADDR_OTADATA):
            return True
    return False


def find_boot_app0(search_dir=None):
    """Locate boot_app0.bin in a build folder or the local Arduino ESP32 package."""
    if search_dir:
        candidate = Path(search_dir).resolve() / "boot_app0.bin"
        if candidate.is_file():
            return str(candidate)

    arduino_root = Path(os.environ.get("LOCALAPPDATA", "")) / "Arduino15" / "packages" / "esp32"
    if arduino_root.is_dir():
        matches = sorted(arduino_root.rglob("boot_app0.bin"))
        if matches:
            return str(matches[0])
    return ""


def _collect_flash_images(bootloader=None, partition=None, app=None, boot_app0=None,
                          encrypted=False, chip=None):
    """Return sorted (address, path, label) tuples for files that exist."""
    def resolve(path):
        if not path:
            return ""
        if encrypted and path.endswith(".bin") and not path.endswith(".enc.bin"):
            enc = path.replace(".bin", ".enc.bin")
            return enc if os.path.isfile(enc) else path
        return path

    items = [
        (bootloader_addr(chip), resolve(bootloader), "Bootloader"),
        (ADDR_PARTITION, resolve(partition), "Partition"),
        (ADDR_OTADATA, resolve(boot_app0), "OTA data (boot_app0)"),
        (ADDR_APP, resolve(app), "Application"),
    ]
    return [(addr, path, label) for addr, path, label in items if path and os.path.isfile(path)]


def validate_firmware_set(bootloader=None, partition=None, app=None,
                          boot_app0=None, require_all=True, log_fn=None):
    """Validate firmware inputs — separate binaries (incl. boot_app0 for OTA)."""
    missing = []
    if not bootloader or not os.path.isfile(bootloader):
        missing.append("bootloader")
    if not partition or not os.path.isfile(partition):
        missing.append("partition table")
    if not app or not os.path.isfile(app):
        missing.append("application")

    needs_boot_app0 = partition_has_otadata(partition)
    has_boot_app0 = bool(boot_app0 and os.path.isfile(boot_app0))

    if require_all and missing:
        if log_fn:
            log_fn("ERROR: Missing required firmware binaries.")
            for name in missing:
                log_fn(f"  Missing: {name}")
            log_fn("")
            for line in ARDUINO_HINT.split("\n"):
                log_fn(line)
        return False

    if require_all and needs_boot_app0 and not has_boot_app0:
        if log_fn:
            log_fn("ERROR: Partition table has 'otadata' at 0xE000 — boot_app0.bin is required.")
            log_fn("  Without it the bootloader cannot select the OTA app slot (chip won't run).")
            log_fn("  Copy boot_app0.bin from your Arduino ESP32 package into the build folder,")
            log_fn("  or use Scan Arduino Build Folder (auto-finds it).")
        return False

    return True


def get_encryption_status(port, log_fn=None, esptool_path=None, chip=None):
    """Query chip security info — key programmed and flash encryption state."""
    cmd, env = build_esptool_cmd(
        "--chip", (chip or DEFAULT_CHIP).lower(), "-p", port,
        "--after", "no-reset", "get-security-info",
        esptool_path=esptool_path,
    )
    ok, result = run_cmd(cmd, log_fn=None, env=env)
    text = ""
    if result:
        text = result.stdout + result.stderr

    key_programmed = any(
        marker in text
        for marker in ("XTS_AES_128", "XTS_AES_256", "XTS-AES-128", "XTS-AES-256")
    )
    fe_enabled = "Flash Encryption: Enabled" in text

    if log_fn:
        log_fn("Checking eFuse / encryption status...")
        for line in text.split("\n"):
            stripped = line.strip()
            if stripped and _should_log_line(stripped):
                if any(k in stripped for k in (
                    "Flash Encryption", "Key Purposes", "BLOCK_KEY",
                    "SPI Boot Crypt", "SPI_BOOT_CRYPT",
                )):
                    log_fn(stripped)

    return {
        "ok": ok,
        "key_programmed": key_programmed,
        "flash_encryption_enabled": fe_enabled,
        "text": text,
    }


def ensure_encryption_ready(port, key_file, log_fn=None, espefuse_path=None,
                            uart_disable=False, jtag_disable=False, esptool_path=None,
                            chip=None):
    """
    Verify flash-encryption key is in eFuse before write-flash --encrypt.
    If a key file is provided and eFuse is empty, burn the key automatically.
    """
    status = get_encryption_status(port, log_fn=log_fn, esptool_path=esptool_path, chip=chip)

    if status["key_programmed"]:
        if log_fn:
            log_fn("OK: Flash encryption key is programmed in eFuse.")
        return True

    if log_fn:
        log_fn("")
        log_fn("Flash encryption key is NOT programmed in eFuse yet.")

    if not key_file or not os.path.isfile(key_file):
        if log_fn:
            log_fn("ERROR: Cannot use on-chip encryption without a burned key.")
            log_fn("  1. Generate Key")
            log_fn("  2. Burn Key to Efuse  (or re-run Flash & Encrypt with key file set)")
            log_fn("  3. Then Flash & Encrypt")
        return False

    if log_fn:
        log_fn(f"Auto-burning key from: {key_file}")
    return burn_key_to_efuse(
        key_file, port, log_fn=log_fn,
        espefuse_path=espefuse_path,
        uart_disable=uart_disable,
        jtag_disable=jtag_disable,
        chip=chip,
    )


def flash_bins(port, bootloader=None, partition=None, app=None,
               boot_app0=None, encrypted=True, encrypt_on_device=False, log_fn=None,
               esptool_path=None, key_file=None, espefuse_path=None,
               uart_disable=False, jtag_disable=False, baud=None, chip=None):
    """
    Flash firmware to the selected ESP32 target.

    encrypt_on_device=True: flash PLAINTEXT .bin files with write-flash --encrypt
      (requires key burned to eFuse — auto-burns from key_file if provided).

    encrypted=True: flash pre-encrypted .enc.bin files with --force --no-compress.
    """
    if encrypt_on_device:
        images = _collect_flash_images(
            bootloader, partition, app, boot_app0, encrypted=False, chip=chip,
        )
        if not images:
            if log_fn:
                log_fn("ERROR: No plaintext binaries found to flash")
            return 0
        if log_fn:
            log_fn("Flashing with on-chip encryption (write-flash --encrypt)...")
            log_fn("Using plaintext .bin files — esptool encrypts during download.")
        if not ensure_encryption_ready(
            port, key_file, log_fn=log_fn, espefuse_path=espefuse_path,
            uart_disable=uart_disable, jtag_disable=jtag_disable,
            esptool_path=esptool_path, chip=chip,
        ):
            return 0
        return _flash_images(
            port, images, pre_encrypted=False, encrypt_on_device=True,
            log_fn=log_fn, esptool_path=esptool_path, baud=baud, chip=chip,
        )

    images = _collect_flash_images(
        bootloader, partition, app, boot_app0, encrypted=encrypted, chip=chip,
    )
    if not images:
        if log_fn:
            log_fn("ERROR: No firmware files found to flash")
        return 0
    if encrypted:
        if log_fn:
            log_fn("Flashing pre-encrypted .enc.bin files (--force --no-compress)...")
        return _flash_images(
            port, images, pre_encrypted=True, encrypt_on_device=False,
            log_fn=log_fn, esptool_path=esptool_path, baud=baud, chip=chip,
        )

    if log_fn:
        log_fn("Flashing PLAINTEXT firmware (no encryption) — for boot verification...")
    return _flash_images(
        port, images, pre_encrypted=False, encrypt_on_device=False,
        log_fn=log_fn, esptool_path=esptool_path, baud=baud, chip=chip,
    )


def _flash_images(port, images, pre_encrypted, encrypt_on_device, log_fn=None,
                  esptool_path=None, baud=None, chip=None):
    """
    Flash multiple images in a single esptool write-flash command.

    Matches Arduino esptool layout (bootloader offset is chip-specific):
      <bl> bootloader, 0x8000 partitions, 0xe000 boot_app0, 0x10000 app

    On-chip encrypt: --compress (-z) + --encrypt + hard-reset (faster, lets chip boot).
    Pre-encrypted:   --force --no-compress + no-reset (Windows COM safety).

    baud defaults to 115200 (no re-enumeration on native USB-CDC).
    """
    if log_fn:
        for addr, path, label in images:
            log_fn(f"  {label}: {path} @ {hex(addr)}")

    chip_id = (chip or DEFAULT_CHIP).lower()
    baud = str(baud or DEFAULT_FLASH_BAUD)
    if log_fn and baud != str(DEFAULT_FLASH_BAUD):
        log_fn(f"Using baud {baud}. If you hit 'Cannot configure port' on native USB,")
        log_fn(f"  set Flash baud back to {DEFAULT_FLASH_BAUD} (USB-OTG re-enumerates on baud change).")

    if pre_encrypted:
        args = [
            "--chip", chip_id, "-p", port, "--baud", baud,
            "--before", "default-reset", "--after", "no-reset",
            "write-flash",
            "--force", "--no-compress", "--flash-size", "detect",
        ]
    else:
        args = [
            "--chip", chip_id, "-p", port, "--baud", baud,
            "--before", "default-reset", "--after", "hard-reset",
            "write-flash",
            "--compress", "--flash-size", "detect",
        ]
        if encrypt_on_device:
            args.append("--encrypt")

    for addr, path, _label in images:
        args.extend([hex(addr), path])

    cmd, env = build_esptool_cmd(*args, esptool_path=esptool_path)
    minutes = _estimate_flash_minutes(images, encrypt_on_device=encrypt_on_device)
    if log_fn:
        if encrypt_on_device:
            log_fn("Using Arduino-style flash: --compress --encrypt (live progress below)")
        log_fn(f"Flashing — no timeout limit (estimated ~{minutes} min, depends on image size)...")

    success, _ = run_cmd(cmd, log_fn, env=env, timeout=None, stream=True)
    if success and log_fn:
        log_fn("")
        log_fn(f"Successfully flashed {len(images)} image(s)")
    return len(images) if success else 0


def flash_plaintext(port, bootloader=None, partition=None, app=None,
                    boot_app0=None, log_fn=None, esptool_path=None, baud=None, chip=None):
    """
    Flash UNENCRYPTED firmware to verify the build boots before encrypting.

    Equivalent to the standard Arduino esptool upload:
      write-flash -z <bl> bootloader 0x8000 partitions 0xe000 boot_app0 0x10000 app
    """
    if not validate_firmware_set(
        bootloader, partition, app, boot_app0=boot_app0,
        require_all=True, log_fn=log_fn,
    ):
        return 0
    return flash_bins(
        port, bootloader, partition, app, boot_app0=boot_app0,
        encrypted=False, encrypt_on_device=False,
        log_fn=log_fn, esptool_path=esptool_path, baud=baud, chip=chip,
    )


def flash_encrypt_on_device(port, bootloader=None, partition=None, app=None,
                            boot_app0=None, key_file=None, log_fn=None, esptool_path=None,
                            espefuse_path=None, uart_disable=False, jtag_disable=False,
                            baud=None, chip=None):
    """Flash plaintext binaries with on-chip encryption (best for Arduino workflow)."""
    if not validate_firmware_set(
        bootloader, partition, app, boot_app0=boot_app0,
        require_all=True, log_fn=log_fn,
    ):
        return 0
    return flash_bins(
        port, bootloader, partition, app, boot_app0=boot_app0,
        encrypt_on_device=True, log_fn=log_fn, esptool_path=esptool_path,
        key_file=key_file, espefuse_path=espefuse_path,
        uart_disable=uart_disable, jtag_disable=jtag_disable, baud=baud, chip=chip,
    )


def encrypt_bins(key_file, bootloader=None, partition=None, app=None,
                 boot_app0=None, log_fn=None, esptool_path=None, chip=None):
    """Encrypt bootloader, partition, app, and boot_app0 binaries offline."""
    files = [
        (bootloader, bootloader_addr(chip), "Bootloader"),
        (partition, ADDR_PARTITION, "Partition Table"),
        (boot_app0, ADDR_OTADATA, "OTA data (boot_app0)"),
        (app, ADDR_APP, "Application"),
    ]

    encrypted = 0
    for path, addr, name in files:
        if not path:
            continue
        if log_fn:
            log_fn("")
            log_fn(f"Encrypting {name}:")
        if encrypt_file(key_file, path, addr, log_fn=log_fn,
                        esptool_path=esptool_path, chip=chip):
            encrypted += 1

    return encrypted


def scan_arduino_bins(search_dir=".", log_fn=None):
    """
    Scan a directory for Arduino ESP32 build artifacts.
    Returns dict with keys bootloader, partition, app (paths or empty string).
    """
    base = Path(search_dir).resolve()
    result = {"bootloader": "", "partition": "", "boot_app0": "", "app": ""}

    if not base.is_dir():
        return result

    bins = list(base.glob("*.bin"))
    for path in bins:
        name = path.name.lower()
        if "merged" in name:
            continue
        if name == "boot_app0.bin":
            result["boot_app0"] = str(path)
        elif name.endswith(".bootloader.bin"):
            result["bootloader"] = str(path)
        elif name.endswith(".partitions.bin") or name.endswith(".partition.bin"):
            result["partition"] = str(path)
        elif name.endswith(".ino.bin"):
            result["app"] = str(path)
        elif name.endswith(".bin") and "bootloader" not in name and "partition" not in name:
            if not result["app"]:
                result["app"] = str(path)

    if not result["boot_app0"] and partition_has_otadata(result["partition"]):
        result["boot_app0"] = find_boot_app0(str(base))

    if log_fn:
        found = sum(1 for v in result.values() if v)
        log_fn(f"Arduino scan in {base}: found {found}/4 binaries")
        for key, path in result.items():
            if path:
                log_fn(f"  {key}: {path}")
        if result["partition"] and partition_has_otadata(result["partition"]) and not result["boot_app0"]:
            log_fn("  WARNING: otadata partition detected but boot_app0.bin not found")

    return result


def read_chip_info(port, log_fn=None, esptool_path=None, chip=None):
    """Read and log chip information (single connection, no reset)."""
    if log_fn:
        log_fn("Reading chip information...")

    chip_id = (chip or DEFAULT_CHIP).lower()
    cmd, env = build_esptool_cmd(
        "--chip", chip_id, "-p", port,
        "--after", "no-reset",
        "chip-id",
        esptool_path=esptool_path,
    )
    ok, result = run_cmd(cmd, log_fn, env=env)

    if log_fn:
        bl = bootloader_addr(chip)
        log_fn("")
        log_fn(f"Flash Memory Map ({chip_profile(chip)['label']}):")
        if bl > 0:
            log_fn(f"  0x00000 - {hex(bl - 1).upper()[2:].rjust(5, '0')}   Boot ROM / reserved")
        log_fn(f"  {hex(bl).upper()}   Bootloader")
        log_fn("  0x08000   Partition Table")
        log_fn("  0x0E000   OTA data (boot_app0)")
        log_fn("  0x10000   Application")

    if not ok and result and result.stdout.strip():
        return "Chip type:" in result.stdout or "Connected to ESP32" in result.stdout

    return ok


def run_efuse_summary(port, log_fn=None, espefuse_path=None, chip=None):
    """Print efuse summary."""
    cmd, env = build_espefuse_cmd(
        "--chip", (chip or DEFAULT_CHIP).lower(), "-p", port, "summary",
        espefuse_path=espefuse_path,
    )
    run_cmd(cmd, log_fn, env=env)


def timestamp():
    return datetime.now().strftime("%H:%M:%S")
