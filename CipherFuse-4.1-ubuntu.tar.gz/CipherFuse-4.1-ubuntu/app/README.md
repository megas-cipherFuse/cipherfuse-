# CipherFuse

**Flash encryption for ESP32 boards. Free.**

Version 4.1 · GPL-3.0 · https://cipherfuse.dev

![Logo](assets/cipherfuse_logo.png)

CipherFuse generates a key, burns it into the chip, and flashes Arduino or ESP-IDF
firmware so the flash is encrypted. It bundles esptool, espefuse, and espsecure.
You do not need a separate ESP-IDF install.

Supported chips: ESP32, S2, S3, C2, C3, C6, H2, P4.

CipherFuse is an independent project. It is not affiliated with Espressif Systems.
ESP32 is a trademark of Espressif Systems.

## Install

Windows installer and portable build:

```powershell
powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
powershell -ExecutionPolicy Bypass -File packaging\build_msi.ps1
```

From source:

```bash
pip install -r requirements.txt
python esp32_flash_encrypt_qt_v3.py
```

## Safe order of work

1. Flash plaintext and confirm the board runs.
2. Generate a key and copy it somewhere safe.
3. Flash & Encrypt. This can burn eFuses and cannot be undone.

Details: [docs/Quick-Start.md](docs/Quick-Start.md) · [docs/Home.md](docs/Home.md)

## Donations

The app is free. If it saved you a board, a donation helps keep it maintained.
See [DONATE.md](DONATE.md).

## License

GNU GPL v3.0. See [LICENSE](LICENSE) and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
Why it cannot be sold as closed-source: [docs/Licensing.md](docs/Licensing.md).
