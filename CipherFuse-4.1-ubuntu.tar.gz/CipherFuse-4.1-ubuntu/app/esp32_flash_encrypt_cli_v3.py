#!/usr/bin/env python3
"""
ESP32-S2 Flash Encryption Tool v3 — CLI
"""

import argparse
import os
import sys

from flash_encrypt_core import (
    VERSION, APP_NAME, COMPANY, DEFAULT_FLASH_BAUD, DEFAULT_CHIP,
    CHIP_PROFILES, chip_profile, default_key_path,
    generate_key_file, burn_key_to_efuse, encrypt_bins, flash_bins,
    flash_encrypt_on_device, flash_plaintext, validate_firmware_set,
    run_efuse_summary, read_chip_info,
)


class Colors:
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    END = "\033[0m"


def log(msg, level="info"):
    palette = {
        "info": Colors.CYAN,
        "success": Colors.GREEN,
        "warning": Colors.YELLOW,
        "error": Colors.RED,
        "dim": Colors.DIM,
        "header": Colors.BOLD + Colors.CYAN,
    }
    print(f"{palette.get(level, '')}{msg}{Colors.END}")


def header(title):
    print()
    log("=" * 60, "header")
    log(f"  {title}", "header")
    log("=" * 60, "header")


def cmd_generate_key(args):
    header("GENERATE ENCRYPTION KEY")
    generate_key_file(args.output or default_key_path(), log_fn=lambda m: log(f"  {m}", "info"))
    return True


def cmd_burn_key(args):
    header(f"BURN KEY TO EFUSE — {args.port} ({chip_profile(args.chip)['label']})")
    return burn_key_to_efuse(
        args.key, args.port,
        log_fn=lambda m: log(f"  {m}", "info"),
        espefuse_path=args.espefuse,
        uart_disable=args.uart_disable,
        jtag_disable=args.jtag_disable,
        chip=args.chip,
    )


def cmd_encrypt(args):
    header("ENCRYPT BINARY FILES")
    if not os.path.isfile(args.key):
        log(f"ERROR: Key not found: {args.key}", "error")
        return False

    if not any([args.bootloader, args.partition, args.app, args.boot_app0]):
        log("ERROR: Specify at least one of -b, -t, -a, or --boot-app0", "error")
        return False

    count = encrypt_bins(
        args.key,
        bootloader=args.bootloader,
        partition=args.partition,
        app=args.app,
        boot_app0=args.boot_app0,
        log_fn=lambda m: log(f"  {m}", "info"),
        esptool_path=args.esptool,
        chip=args.chip,
    )
    log(f"Encrypted {count} file(s)", "success" if count else "error")
    return count > 0


def cmd_flash(args):
    header(f"FLASH ENCRYPTED BINARIES — {args.port} ({chip_profile(args.chip)['label']})")
    count = flash_bins(
        args.port,
        bootloader=args.bootloader,
        partition=args.partition,
        app=args.app,
        boot_app0=args.boot_app0,
        encrypted=True,
        log_fn=lambda m: log(f"  {m}", "info"),
        esptool_path=args.esptool,
        baud=args.baud,
        chip=args.chip,
    )
    log(f"Flashed {count} file(s)", "success" if count else "error")
    return count > 0


def cmd_flash_plain(args):
    header(f"FLASH PLAINTEXT FIRMWARE — {args.port} ({chip_profile(args.chip)['label']})")
    log("No encryption — verify the firmware boots before encrypting.", "warning")
    count = flash_plaintext(
        args.port,
        bootloader=args.bootloader,
        partition=args.partition,
        app=args.app,
        boot_app0=args.boot_app0,
        log_fn=lambda m: log(f"  {m}", "info"),
        esptool_path=args.esptool,
        baud=args.baud,
        chip=args.chip,
    )
    log(f"Flashed {count} plaintext file(s)", "success" if count else "error")
    return count > 0


def cmd_full(args):
    header("FULL FLASH ENCRYPTION PROCESS")
    key = args.key or default_key_path()

    log("\n[1/4] Key generation", "info")
    if not os.path.isfile(key):
        generate_key_file(key, log_fn=lambda m: log(f"  {m}", "info"))
    else:
        log(f"  Using existing key: {key}", "info")

    log("\n[2/4] Burn key", "info")
    if not burn_key_to_efuse(
        key, args.port,
        log_fn=lambda m: log(f"  {m}", "info"),
        espefuse_path=args.espefuse,
        uart_disable=args.uart_disable,
        jtag_disable=args.jtag_disable,
        chip=args.chip,
    ):
        return False

    if not validate_firmware_set(args.bootloader, args.partition, args.app,
                                 boot_app0=args.boot_app0, require_all=True,
                                 log_fn=lambda m: log(f"  {m}", "error")):
        return False

    log("\n[3/4] Offline .enc.bin backups", "info")
    encrypt_bins(
        key,
        bootloader=args.bootloader,
        partition=args.partition,
        app=args.app,
        boot_app0=args.boot_app0,
        log_fn=lambda m: log(f"  {m}", "info"),
        esptool_path=args.esptool,
        chip=args.chip,
    )

    log("\n[4/4] Flash with on-chip encryption", "info")
    flashed = flash_encrypt_on_device(
        args.port,
        bootloader=args.bootloader,
        partition=args.partition,
        app=args.app,
        boot_app0=args.boot_app0,
        key_file=key,
        log_fn=lambda m: log(f"  {m}", "info"),
        esptool_path=args.esptool,
        espefuse_path=args.espefuse,
        uart_disable=args.uart_disable,
        jtag_disable=args.jtag_disable,
        baud=args.baud,
        chip=args.chip,
    )
    if flashed == 0:
        log("ERROR: Flash failed", "error")
        return False

    header("COMPLETE")
    log(f"  Key: {key}", "success")
    log("  Backup your encryption key!", "warning")
    run_efuse_summary(args.port, log_fn=lambda m: log(f"  {m}", "dim"),
                      espefuse_path=args.espefuse, chip=args.chip)
    return True


def cmd_info(args):
    header(f"CHIP INFO — {chip_profile(args.chip)['label']}")
    ok = read_chip_info(
        args.port,
        log_fn=lambda m: log(f"  {m}", "dim"),
        esptool_path=args.esptool,
        chip=args.chip,
    )
    if not ok:
        log("Could not read chip. Check connection.", "warning")
    return True


def cmd_verify(args):
    header("VERIFY FLASH ENCRYPTION")
    run_efuse_summary(args.port, log_fn=lambda m: log(f"  {m}", "info"),
                      espefuse_path=args.espefuse, chip=args.chip)
    return True


def build_parser():
    parser = argparse.ArgumentParser(
        description=f"{APP_NAME} v{VERSION} — {COMPANY}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python esp32_flash_encrypt_cli_v3.py generate_key
  python esp32_flash_encrypt_cli_v3.py burn_key -p COM3 -k key.bin
  python esp32_flash_encrypt_cli_v3.py encrypt -k key.bin -a app.bin
  python esp32_flash_encrypt_cli_v3.py flash_plain -p COM3 -b boot.bin -t part.bin --boot-app0 boot_app0.bin -a app.bin
  python esp32_flash_encrypt_cli_v3.py flash -p COM3 -a app.bin
  python esp32_flash_encrypt_cli_v3.py full -p COM3 --chip esp32s3 -a app.bin

Supported chips: """ + ", ".join(CHIP_PROFILES.keys()) + """
        """,
    )
    sub = parser.add_subparsers(dest="command")

    # Shared --chip option for every command that talks to a device.
    chip_parent = argparse.ArgumentParser(add_help=False)
    chip_parent.add_argument(
        "--chip", default=DEFAULT_CHIP, choices=list(CHIP_PROFILES.keys()),
        help=f"Target chip (default: {DEFAULT_CHIP})",
    )

    gen = sub.add_parser("generate_key")
    gen.add_argument("-o", "--output", help="Output key path")

    burn = sub.add_parser("burn_key", parents=[chip_parent])
    burn.add_argument("-p", "--port", default="COM3")
    burn.add_argument("-k", "--key", required=True)
    burn.add_argument("--espefuse", help="Path to espefuse tool directory")
    burn.add_argument("--uart-disable", action="store_true")
    burn.add_argument("--jtag-disable", action="store_true")

    enc = sub.add_parser("encrypt", parents=[chip_parent])
    enc.add_argument("-k", "--key", required=True)
    enc.add_argument("-b", "--bootloader")
    enc.add_argument("-t", "--partition")
    enc.add_argument("-a", "--app")
    enc.add_argument("--boot-app0", help="boot_app0.bin for otadata @ 0xE000")
    enc.add_argument("--esptool", help="Path to esptool directory")

    flash = sub.add_parser("flash", parents=[chip_parent])
    flash.add_argument("-p", "--port", default="COM3")
    flash.add_argument("-b", "--bootloader")
    flash.add_argument("-t", "--partition")
    flash.add_argument("-a", "--app")
    flash.add_argument("--boot-app0", help="boot_app0.bin for otadata @ 0xE000")
    flash.add_argument("--baud", default=str(DEFAULT_FLASH_BAUD),
                       help="Flash baud (use 115200 for native USB / USB-OTG)")
    flash.add_argument("--esptool", help="Path to esptool directory")

    flash_plain = sub.add_parser("flash_plain", parents=[chip_parent],
                                 help="Flash UNENCRYPTED firmware (boot test)")
    flash_plain.add_argument("-p", "--port", default="COM3")
    flash_plain.add_argument("-b", "--bootloader")
    flash_plain.add_argument("-t", "--partition")
    flash_plain.add_argument("-a", "--app")
    flash_plain.add_argument("--boot-app0", help="boot_app0.bin for otadata @ 0xE000")
    flash_plain.add_argument("--baud", default=str(DEFAULT_FLASH_BAUD),
                             help="Flash baud (use 115200 for native USB / USB-OTG)")
    flash_plain.add_argument("--esptool", help="Path to esptool directory")

    full = sub.add_parser("full", parents=[chip_parent])
    full.add_argument("-p", "--port", default="COM3")
    full.add_argument("-k", "--key")
    full.add_argument("-b", "--bootloader")
    full.add_argument("-t", "--partition")
    full.add_argument("-a", "--app")
    full.add_argument("--boot-app0", help="boot_app0.bin for otadata @ 0xE000")
    full.add_argument("--baud", default=str(DEFAULT_FLASH_BAUD),
                      help="Flash baud (use 115200 for native USB / USB-OTG)")
    full.add_argument("--esptool", help="Path to esptool directory")
    full.add_argument("--espefuse", help="Path to espefuse directory")
    full.add_argument("--uart-disable", action="store_true")
    full.add_argument("--jtag-disable", action="store_true")

    info = sub.add_parser("info", parents=[chip_parent])
    info.add_argument("-p", "--port", default="COM3")
    info.add_argument("--esptool", help="Path to esptool directory")

    verify = sub.add_parser("verify", parents=[chip_parent])
    verify.add_argument("-p", "--port", default="COM3")
    verify.add_argument("--espefuse", help="Path to espefuse directory")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 1

    commands = {
        "generate_key": cmd_generate_key,
        "burn_key": cmd_burn_key,
        "encrypt": cmd_encrypt,
        "flash": cmd_flash,
        "flash_plain": cmd_flash_plain,
        "full": cmd_full,
        "info": cmd_info,
        "verify": cmd_verify,
    }

    try:
        ok = commands[args.command](args)
        return 0 if ok else 1
    except KeyboardInterrupt:
        log("\nCancelled.", "warning")
        return 130


if __name__ == "__main__":
    sys.exit(main())
