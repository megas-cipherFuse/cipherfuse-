# Arduino Workflow

## 1. Export the binaries from Arduino IDE

In Arduino IDE: **Sketch → Export Compiled Binary**. This writes the build files
into your sketch's `build/` folder. You need four files:

- `Sketch.ino.bootloader.bin`
- `Sketch.ino.partitions.bin`
- `boot_app0.bin`  ← the OTA slot selector
- `Sketch.ino.bin` ← your application

> If you can't find them, enable **Show verbose output during compilation** in
> Preferences and watch the log for the temp build path, or use
> **Scan Arduino Build Folder** and point it at the temp folder.

## 2. Why `boot_app0.bin` matters

Default Arduino partition schemes include an **otadata** partition at `0xE000`. The
bootloader reads it to decide which OTA app slot to run. If otadata is left erased
(`0xFF`), the bootloader can't pick a slot and **your app never starts** — even
though it flashed fine.

`boot_app0.bin` initializes otadata to "run app slot 0". This tool detects an
otadata partition and requires `boot_app0.bin`; **Scan Arduino Build Folder** finds
it automatically (it ships with the Arduino ESP32 core).

## 3. Match the chip

Pick the same chip in the tool that you selected as the Arduino board. The bootloader
offset differs by chip (e.g. S3/C3 use `0x0`, classic ESP32/S2 use `0x1000`). Getting
this wrong is the usual cause of a board that flashes but won't boot.

## 4. Recommended order

1. **Flash Plaintext (Test)** — prove the build boots unencrypted.
2. **Generate New Key** and back it up.
3. **Flash & Encrypt** — burns the key (if needed) and flashes encrypted.

## 5. Updating later

While in development mode you can rebuild in Arduino and run **Flash & Encrypt**
again with the *same* key file. For production updates, prefer encrypted OTA from
within your firmware.
