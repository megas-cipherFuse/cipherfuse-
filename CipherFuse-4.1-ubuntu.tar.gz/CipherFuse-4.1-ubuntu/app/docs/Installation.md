# Installation

## Option A — Windows installer (recommended for users)

1. Download `CipherFuse-Setup-<version>.exe` or the `.msi` from the Releases page.
2. Run it and follow the wizard (installs to `Program Files\CipherFuse`).
3. Launch **CipherFuse** from the Start menu.

Everything (esptool, espefuse, espsecure, fonts) is bundled — there is nothing
else to install and no PATH configuration.

## Option B — Portable

If you don't want to install, grab the `CipherFuse` folder (the
PyInstaller one-folder build) and run `CipherFuse.exe` directly from any
location, including a USB stick.

## Option C — Run from source (developers)

Requirements: Python 3.9+.

```bash
pip install -r requirements.txt
python esp32_flash_encrypt_qt_v3.py      # GUI
python esp32_flash_encrypt_cli_v3.py --help   # CLI
```

The repository bundles a copy of `esptool/` (which also contains `espefuse` and
`espsecure`). The tool runs them with `python -m esptool` and sets `PYTHONPATH`
automatically, so you do not need a separate esptool install.

## USB drivers

- **Native USB chips** (ESP32-S2/S3/C3/C6/H2 with the USB pins wired): usually
  enumerate as a COM port with no driver on Windows 10/11.
- **USB-UART bridge boards** (CP2102, CH340, FTDI): install the vendor driver if
  the board does not show up as a COM port.

See [[Troubleshooting]] if no port appears.
