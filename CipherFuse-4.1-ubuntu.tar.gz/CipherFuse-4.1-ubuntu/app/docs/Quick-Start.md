# Quick Start

This walks you from a freshly compiled firmware to an encrypted board.

> Do this on a board you can afford to lock. Flash encryption burns eFuses and is
> **permanent**.

## 1. Select your chip and port

On the **Operations** tab:

- **Target Chip** → pick your variant (ESP32, S2, S3, C3, …). This sets the
  bootloader offset and encryption scheme automatically.
- **Serial Port** → pick the COM port. Click **Read Chip Info** to confirm the
  tool can talk to the board.

## 2. Point to your firmware

On the **Firmware** tab, click **Scan Arduino Build Folder** and select your
sketch's build output. The tool auto-fills the four binaries:

| File | Address |
|------|---------|
| `Sketch.ino.bootloader.bin` | chip-specific (0x0 / 0x1000 / 0x2000) |
| `Sketch.ino.partitions.bin` | 0x8000 |
| `boot_app0.bin` | 0xE000 |
| `Sketch.ino.bin` | 0x10000 |

## 3. Verify it boots (plaintext)

Click **Flash Plaintext (Test)**. This flashes the firmware **without** encryption.
Confirm the board runs your sketch (serial monitor / LED / etc.) before locking it.

## 4. Generate and back up a key

Back on **Operations**: set a key file path → **Generate New Key**.
**Copy that `.bin` key somewhere safe.** Without it you cannot do future encrypted
OTA-style updates or re-flash.

## 5. Flash with encryption

On **Firmware**, click **Flash & Encrypt**. The tool will:

1. Burn the key to eFuse if it isn't already there.
2. Enable flash encryption (`SPI_BOOT_CRYPT_CNT` / `FLASH_CRYPT_CNT`).
3. Flash your plaintext binaries with `write-flash --encrypt` — the chip encrypts
   them during download.

When it finishes, the board reboots running encrypted firmware.

---

### CLI equivalent

```bash
python esp32_flash_encrypt_cli_v3.py full -p COM3 --chip esp32s3 \
  -b build/app.ino.bootloader.bin \
  -t build/app.ino.partitions.bin \
  --boot-app0 build/boot_app0.bin \
  -a build/app.ino.bin
```

See [[CLI Reference]] for all commands.
