# Troubleshooting

## "Permission denied" / `Access is denied`

Two common causes:

### 1. Serial port is locked (most common when flashing)

Another program already has the COM port open.

**Fix:**
1. Close **Arduino Serial Monitor**, PuTTY, CoolTerm, PlatformIO monitor, etc.
2. Unplug/replug the USB cable.
3. Click **Refresh** in the tool and pick the port again.
4. Retry the operation.

You do **not** normally need to "Run as administrator" for COM ports.

### 2. Writing a file into a protected folder

If you installed via MSI into `Program Files`, generating a key (or `.enc.bin`) in that
folder fails with Permission denied.

**Fix:** save the key under Documents. The tool now defaults to:

`Documents\CipherFuse\flash_encryption_key.bin`

Or Browse to any folder you own.

---

## "Cannot configure port" / `OSError(22, 'A device which does not exist...')`

Almost always a **native USB** chip (S2/S3/C3/...) re-enumerating when esptool
changes the baud rate.

**Fix:** set **Flash baud = 115200** (Settings tab, or `--baud 115200`). This is the
default. Only raise it for real USB-UART bridge boards.

## The board flashes successfully but doesn't run my app

Two usual causes:

1. **Missing `boot_app0.bin`.** If the partition table has otadata (`0xE000`) and
   it's left erased, the bootloader can't select an app slot. Include
   `boot_app0.bin` — **Scan Arduino Build Folder** finds it. See [[Arduino Workflow]].
2. **Wrong chip selected.** The bootloader offset differs per chip (S3/C3 = `0x0`,
   ESP32/S2 = `0x1000`). Pick the correct **Target Chip**.

## "Flash encryption key is not programmed"

You tried **Flash .enc.bin** or on-chip encrypt without a key in eFuse. Set a key
file on the Operations tab and run **Flash & Encrypt** (it auto-burns the key), or
run `burn_key` first.

## Key burn seems to hang / times out

Older behavior: `espefuse` waited for an interactive `BURN` confirmation. This tool
passes `--do-not-confirm` so it won't hang. If you still see a timeout, the device
likely isn't in download mode — replug, hold BOOT, and retry.

## No COM port appears

- Try another USB cable (some are charge-only).
- For CP2102/CH340/FTDI bridge boards, install the vendor driver.
- Click **Refresh** in the tool after plugging in.
- On native-USB boards, hold **BOOT**, tap **RESET**, release BOOT to force download
  mode, then refresh.

## Flash is slow

Over native USB, 115200 and 921600 are the same speed (virtual baud). Large apps
just take time to encrypt on-chip. The log streams live progress — it isn't frozen.

## Frozen `.exe`: "No module named ..." when it shells out

The packaged app runs its bundled esptool by re-execing itself with `--run-tool=`.
If you rebuilt the spec and a tool dependency is missing, add it to the
`collect_all(...)` list in `packaging/autoponix.spec`. See [[Building From Source]].
