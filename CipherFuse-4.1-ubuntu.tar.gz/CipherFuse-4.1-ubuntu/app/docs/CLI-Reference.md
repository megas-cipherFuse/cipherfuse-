# CLI Reference

```bash
python esp32_flash_encrypt_cli_v3.py <command> [options]
```

Most commands accept `--chip` (default `esp32s2`). Supported values:
`esp32, esp32s2, esp32s3, esp32c2, esp32c3, esp32c6, esp32h2, esp32p4`.

Common file options:

| Flag | Meaning |
|------|---------|
| `-p, --port` | Serial port (e.g. `COM3`, `/dev/ttyUSB0`) |
| `-b, --bootloader` | bootloader bin |
| `-t, --partition` | partition table bin |
| `--boot-app0` | `boot_app0.bin` (otadata @ 0xE000) |
| `-a, --app` | application bin |
| `-k, --key` | encryption key file |
| `--baud` | flash baud (keep `115200` for native USB) |

## Commands

### `generate_key`
Create a new 256-bit key.
```bash
python esp32_flash_encrypt_cli_v3.py generate_key -o mykey.bin
```

### `burn_key`
Burn the key to eFuse and enable flash encryption.
```bash
python esp32_flash_encrypt_cli_v3.py burn_key -p COM3 --chip esp32s3 -k mykey.bin
```
Options: `--uart-disable`, `--jtag-disable` (permanent lockdown — use with care).

### `flash_plain`
Flash **unencrypted** firmware to verify it boots.
```bash
python esp32_flash_encrypt_cli_v3.py flash_plain -p COM3 --chip esp32c3 \
  -b boot.bin -t part.bin --boot-app0 boot_app0.bin -a app.bin
```

### `encrypt`
Create offline `.enc.bin` backups for the selected chip's scheme.
```bash
python esp32_flash_encrypt_cli_v3.py encrypt --chip esp32 -k mykey.bin -a app.bin
```

### `flash`
Flash pre-encrypted `.enc.bin` files.
```bash
python esp32_flash_encrypt_cli_v3.py flash -p COM3 --chip esp32s3 \
  -b boot.bin -t part.bin --boot-app0 boot_app0.bin -a app.bin
```

### `full`
Generate (if needed) → burn → make `.enc.bin` backups → flash with on-chip
encryption, in one run.
```bash
python esp32_flash_encrypt_cli_v3.py full -p COM3 --chip esp32s2 -k mykey.bin \
  -b boot.bin -t part.bin --boot-app0 boot_app0.bin -a app.bin
```

### `info`
Read chip id and the flash memory map for the selected chip.
```bash
python esp32_flash_encrypt_cli_v3.py info -p COM3 --chip esp32s3
```

### `verify`
Print the eFuse summary.
```bash
python esp32_flash_encrypt_cli_v3.py verify -p COM3 --chip esp32s3
```
