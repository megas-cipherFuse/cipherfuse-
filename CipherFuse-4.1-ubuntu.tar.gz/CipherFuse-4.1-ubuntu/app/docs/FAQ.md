# FAQ

**Is flash encryption reversible?**
No. Burning eFuses is permanent. You cannot disable encryption or read the key back.

**Can I lose access to my board?**
Yes — if you lose the key and need a key-based update later. Always back up the key
file produced by **Generate New Key**.

**Do I need ESP-IDF installed?**
No. esptool/espefuse/espsecure are bundled. The packaged `.exe` needs nothing extra.

**Which chips are supported?**
ESP32, S2, S3, C2, C3, C6, H2, P4. See [[Supported Chips]].

**Does encryption protect against someone with the running device?**
It protects firmware **at rest** in flash. It is not a substitute for Secure Boot
(which verifies firmware authenticity). For strong protection, use both.

**Can I still use OTA updates?**
Yes, but OTA images must be handled per the encryption scheme. In development mode
you can re-flash with `--encrypt`; for production use encrypted OTA from firmware.

**What's the difference between "Flash & Encrypt" and "Flash .enc.bin"?**
- *Flash & Encrypt*: sends plaintext, the chip encrypts during download (recommended).
- *Flash .enc.bin*: sends files you already encrypted offline with `espsecure`.

**Why must I keep baud at 115200?**
Native USB chips drop the port when the baud changes mid-flash. See
[[Troubleshooting]].

**Is it free? Can I use it commercially?**
See the project LICENSE. The tool is provided under an open-source license; the
bundled `esptool` is GPL-2.0 (Espressif). See [[Building From Source]] for notes.
