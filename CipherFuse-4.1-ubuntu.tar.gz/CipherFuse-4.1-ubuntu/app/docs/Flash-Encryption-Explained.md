# Flash Encryption Explained

## The idea

Flash encryption stores your firmware **encrypted** in the SPI flash. A key burned
into the chip's eFuses (write-/read-protected hardware fuses) is used by the ROM
bootloader to decrypt code transparently at boot. Someone who dumps the flash sees
ciphertext, not your program.

## What gets burned

1. **The key** → a key eFuse block:
   - ESP32: 256-bit key in `BLOCK1`.
   - S2/S3/C-series/H2/P4: key in `BLOCK_KEY0` with purpose `XTS_AES_128_KEY`.
   The block is read-protected, so the key can never be read back over the wire.

2. **The enable counter** → `SPI_BOOT_CRYPT_CNT` (newer) or `FLASH_CRYPT_CNT`
   (ESP32). Setting it tells the ROM "this flash is encrypted; decrypt on boot".

3. **ESP32 only:** `FLASH_CRYPT_CONFIG = 0xF` for full tweak/range coverage.

These are **one-way** operations. You cannot un-burn an eFuse.

## Two ways to get encrypted bytes into flash

### A) On-chip encryption (what "Flash & Encrypt" does)

You send **plaintext** binaries with `esptool write-flash --encrypt`. The chip
encrypts each block as it is written, using the key already in eFuse. This is the
most reliable path for the Arduino workflow and is the default in this tool.

### B) Offline encryption (`.enc.bin` files)

`espsecure encrypt-flash-data` encrypts each binary on your PC, producing
`*.enc.bin`. You then flash those with `write-flash --force --no-compress`. The
encryption is **address-dependent**, so each file must be encrypted for the exact
flash offset it will live at. This tool creates `.enc.bin` backups during the full
process and can flash them with **Flash .enc.bin**.

## Development vs Release mode (important)

The chip supports two modes:

- **Development mode** lets you re-flash encrypted firmware several times (the crypt
  counter allows multiple updates). Good while iterating.
- **Release mode** locks things down — after it's set you generally cannot re-flash
  over UART/USB, only via signed OTA from your own firmware.

This tool performs the standard burn that leaves you able to re-flash with
`--encrypt` in development scenarios. Be deliberate before enabling the extra
lockdown options (UART download disable, JTAG disable) in **Settings** — they are
permanent.

## Why back up the key?

If you later want to update firmware **without** erasing the chip (e.g. encrypted
OTA, or re-flashing matching ciphertext), you need the same key. The key is
read-protected on the chip, so the copy you saved at generation time is the only
copy. Lose it and that board is effectively frozen on its current firmware.
