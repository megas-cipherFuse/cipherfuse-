# Supported Chips

Select the target on the **Operations** tab (GUI) or with `--chip` (CLI). The tool
adjusts the bootloader offset, the eFuse key block/purpose, the enable eFuse, and
the offline-encryption scheme for you.

| Chip | `--chip` value | Bootloader | Scheme | Key block | Enable eFuse |
|------|----------------|-----------|--------|-----------|--------------|
| ESP32 (classic) | `esp32` | `0x1000` | AES-256 (FLASH_CRYPT_CONFIG) | BLOCK1 (`flash_encryption`) | `FLASH_CRYPT_CNT` |
| ESP32-S2 | `esp32s2` | `0x1000` | XTS-AES-128 | `BLOCK_KEY0` | `SPI_BOOT_CRYPT_CNT` |
| ESP32-S3 | `esp32s3` | `0x0` | XTS-AES-128 | `BLOCK_KEY0` | `SPI_BOOT_CRYPT_CNT` |
| ESP32-C2 | `esp32c2` | `0x0` | XTS-AES-128 | `BLOCK_KEY0` | `SPI_BOOT_CRYPT_CNT` |
| ESP32-C3 | `esp32c3` | `0x0` | XTS-AES-128 | `BLOCK_KEY0` | `SPI_BOOT_CRYPT_CNT` |
| ESP32-C6 | `esp32c6` | `0x0` | XTS-AES-128 | `BLOCK_KEY0` | `SPI_BOOT_CRYPT_CNT` |
| ESP32-H2 | `esp32h2` | `0x0` | XTS-AES-128 | `BLOCK_KEY0` | `SPI_BOOT_CRYPT_CNT` |
| ESP32-P4 | `esp32p4` | `0x2000` | XTS-AES-128 | `BLOCK_KEY0` | `SPI_BOOT_CRYPT_CNT` |

The partition table (`0x8000`), OTA data / `boot_app0` (`0xE000`), and the app
(`0x10000`) live at the same offsets on every chip for the standard Arduino layout —
only the **bootloader** offset changes.

## Two encryption schemes

- **Original ESP32** uses an AES-256 scheme configured by `FLASH_CRYPT_CONFIG`
  (offline encryption uses `espsecure --flash-crypt-conf 0xF`, no `--aes-xts`).
- **All newer chips** use **XTS-AES** with the key in `BLOCK_KEY0` and key purpose
  `XTS_AES_128_KEY` (offline encryption uses `espsecure --aes-xts`).

You don't set any of this manually — picking the chip does it.

## Native USB vs UART

S2, S3, C3, C6, H2, and P4 have a built-in USB controller. When you flash over the
native USB port, **keep the flash baud at 115200**. Raising the baud causes the USB
device to re-enumerate mid-flash and drop the COM port (`Cannot configure port` /
`OSError(22)`). Over native USB the baud is virtual anyway, so there is no speed
penalty. Only raise the baud when flashing through a real USB-UART bridge.
