# Licensing — free or commercial?

You asked whether to give this tool away for free or to license it commercially.
Here is the honest, practical answer for *this specific tool*.

## TL;DR recommendation

**Give CipherFuse away under the GNU GPL v3.0 and ask for donations.** Selling a
closed copy is not realistic: the bundled tools force GPL-3.0 on the whole app.
Donations match that, and people trust a security tool they can read.

A `LICENSE` (GPL-3.0) and `THIRD_PARTY_NOTICES.md` are already in the repo.

## Why a closed-source commercial license is hard here

The tool depends on two **copyleft** components:

| Component | License | Consequence |
|-----------|---------|-------------|
| esptool / espefuse / espsecure | GPL-2.0-**or-later** | Distributing it obliges GPL terms; the packaged `.exe` imports it in-process. |
| PyQt6 | GPL-3.0-**only** (or paid commercial) | A closed-source GUI needs a commercial PyQt license from Riverbank. |

Combined, the distributable **must** be GPL-3.0. To make a *closed-source*
commercial product you would have to **all** of:

1. Buy a commercial PyQt license (or rewrite the GUI in a permissive toolkit like
   Tkinter / Dear PyGui / a web UI), **and**
2. Stop bundling/linking esptool in-process — instead call a separately installed
   esptool purely via subprocess ("arm's length"), or replace it.

That's a lot of work that mostly removes the things that make the tool pleasant
(one-click install, bundled tools).

## Why free + open source is the right call

- **Trust.** People are burning permanent eFuses with this. Open code they can
  audit is a feature, not a giveaway.
- **Donations.** A small ask ("if this saved a board") funds maintenance without
  paywalling the installer. See `DONATE.md`.
- **Community contributions.** New chips and fixes can come from users.
- **Zero licensing-compliance risk** for you and your users.

## How donations work here

Keep the app and the Windows installer free. Ask for money only after someone
has used it:

- GitHub Sponsors or Open Collective, linked from the About button and
  https://cipherfuse.dev/#donate
- Optional paid support later, sold as time, not as a locked binary.
- **A hosted / fleet edition** (provisioning many boards, key management, audit
  logs) offered as a service — your server-side code can stay private.
- **Sponsorship / "pro" add-ons** that are themselves GPL but sold as a convenience
  (binaries + support), which is fully allowed under GPL.

## If you specifically want a permissive license for *your* code

You can license **your own source files** (the three `*.py` files) under a permissive
license like Apache-2.0 *in addition*, so others can reuse your wrapper logic.
But note: any **combined distributable** that still includes PyQt6 + esptool remains
GPL-3.0. Apache-2.0 is compatible with GPL-3.0 (not GPL-2.0-only), and esptool's
"or-later" lets the combination be treated as GPL-3.0, so this dual approach is
legal. It mainly helps other developers, not closed-source reuse.

## Bottom line

Ship it free under GPL-3.0. Keep your branding, sell the hardware/support/service
around it, and you get adoption and trust without legal headaches.
