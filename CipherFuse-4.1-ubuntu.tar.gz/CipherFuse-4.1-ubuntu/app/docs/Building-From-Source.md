# Building From Source

## Run without building

```bash
pip install -r requirements.txt
python esp32_flash_encrypt_qt_v3.py
```

## Build the Windows app + installer

One command (from the project root):

```powershell
powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
```

This will:

1. Install build requirements (PyInstaller, Pillow, PyQt6, pyserial).
2. Regenerate `assets/cipherfuse.ico` from the logo PNG.
3. Build a one-folder app → `dist/CipherFuse/CipherFuse.exe`.
4. If [Inno Setup 6](https://jrsoftware.org/isdl.php) is installed, compile an
   `.exe` installer → `dist/installer/CipherFuse-Setup-<ver>.exe`.

Flags:
- `-SkipInstaller` — build the `.exe` only.
- `-Clean` — wipe `build/` and `dist/` first.

## Build the MSI installer

For an `.msi` (Group Policy / enterprise deployment), use the WiX-based script:

```powershell
powershell -ExecutionPolicy Bypass -File packaging\build_msi.ps1 -Version 4.0.0
```

This will:

1. Build the frozen app first if it isn't already (`-SkipInstaller`).
2. Download the **WiX Toolset v3.14** portable binaries into `packaging\.wix\`
   (one-time; no system install, runs on the .NET Framework built into Windows).
3. `heat` harvests the app folder, `candle` compiles `packaging/autoponix.wxs`, and
   `light` links the result → `dist/installer/CipherFuse-<ver>.msi`.

The MSI installs per-machine to `Program Files\CipherFuse`, adds Start-menu
and (optional) desktop shortcuts, supports clean major-upgrades, and appears in
Add/Remove Programs with the app icon. Silent install:

```powershell
msiexec /i CipherFuse-4.1.0.msi /qn
msiexec /i CipherFuse-4.1.0.msi /qn INSTALLDESKTOPSHORTCUT=0   # no desktop icon
msiexec /x CipherFuse-4.1.0.msi /qn                            # uninstall
```

Files: `packaging/autoponix.wxs` (product), `packaging/License.rtf` (EULA dialog text).
The harmless `ICE60` warnings during linking are just two versioned DLLs without a
language column.

## How the frozen app runs esptool

A PyInstaller `.exe` can't do `python -m esptool` (there's no Python interpreter on
PATH inside the bundle). Instead the app **re-execs itself**:

- `flash_encrypt_core.build_*_cmd()` detects `sys.frozen` and emits
  `CipherFuse.exe --run-tool=esptool ...`.
- `esp32_flash_encrypt_qt_v3._dispatch_bundled_tool()` intercepts `--run-tool=` at
  startup, imports that module, and calls its `_main()`.

So the single `.exe` doubles as the GUI **and** as esptool/espefuse/espsecure.

## PyInstaller spec notes

`packaging/autoponix.spec` collects three Espressif packages plus their dynamic
dependencies (`bitstring`, `bitarray`, `ecdsa`, `reedsolo`, `cryptography`). If you
upgrade esptool and hit a `ModuleNotFoundError` at runtime, add the missing package
to the `collect_all(...)` loop in the spec and rebuild.

Data bundled: `fonts/`, `assets/`, and esptool's stub-flasher/target JSON data.

## Licensing note for redistribution

The bundled `esptool` is **GPL-2.0** (Espressif). If you distribute a binary that
includes it, your distribution must comply with GPL-2.0 (provide corresponding
source / offer it). Keep this in mind when choosing a license for your own code —
see the discussion in the project README / LICENSE.
