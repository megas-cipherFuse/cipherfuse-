# CipherFuse — Wiki

A desktop + CLI tool that makes ESP32 **flash encryption** simple: generate a key,
burn it to eFuse, and flash your Arduino/ESP-IDF firmware so it is encrypted at rest
and only boots on the chip that holds the key.

![Logo](../assets/cipherfuse_logo.png)

## Why use this?

Flash encryption normally means juggling `esptool`, `espefuse`, and `espsecure`
commands, the right eFuse names per chip, and chip-specific bootloader offsets. This
tool wraps all of that behind one workflow and bundles the tools — no PATH setup,
no ESP-IDF install required.

## Start here

| Page | What it covers |
|------|----------------|
| [[Installation]] | Install the Windows app or run from source |
| [[Quick Start]] | Encrypt + flash your first board in 5 steps |
| [[Supported Chips]] | ESP32 / S2 / S3 / C2 / C3 / C6 / H2 / P4 details |
| [[Arduino Workflow]] | Going from Arduino IDE build folder to encrypted flash |
| [[Flash Encryption Explained]] | What actually happens on the chip |
| [[CLI Reference]] | Every command and flag |
| [[Troubleshooting]] | Fixing the common errors |
| [[FAQ]] | Short answers to common questions |
| [[Building From Source]] | Build the `.exe` and installer yourself |

## The golden rules

1. **Back up your key.** Lose the key → you can never update that board again.
2. **Flash plaintext first** to confirm the firmware boots, *then* encrypt.
3. **Flash encryption is one-way.** Once eFuses are burned, you cannot disable it.

---
CipherFuse · v4.1 · https://cipherfuse.dev
