# Third-Party Notices

CipherFuse is distributed with the following
third-party components. Each remains under its own license.

| Component | Use | License |
|-----------|-----|---------|
| [esptool / espefuse / espsecure](https://github.com/espressif/esptool) (Espressif) | Flashing, eFuse, offline encryption | **GPL-2.0-or-later** |
| [PyQt6](https://www.riverbankcomputing.com/software/pyqt/) (Riverbank Computing) | Desktop GUI | **GPL-3.0-only** (or commercial) |
| [pyserial](https://github.com/pyserial/pyserial) | Serial port enumeration | BSD-3-Clause |
| Oxanium, Orbitron fonts (Google Fonts) | UI typography | SIL Open Font License 1.1 |

## What this means for distribution

Because the application **combines** GPL-2.0+ (esptool) and GPL-3.0-only (PyQt6)
code — including the packaged `.exe`, which imports esptool/espefuse/espsecure
in-process — the application **as a whole is distributed under the GNU GPL v3.0**
(see `LICENSE`). esptool's "or-later" clause makes it compatible with GPL-3.0.

If you redistribute a build of this tool, you must:

1. Keep it under GPL-3.0 and include the `LICENSE` file.
2. Make the corresponding source available (or a written offer for it).
3. Preserve these notices and the upstream copyright headers.

See [docs/Licensing.md](docs/Licensing.md) for the full reasoning and the options
if you ever want a closed-source/commercial edition.
