#!/usr/bin/env python3
"""
CipherFuse — flash encryption GUI for the ESP32 family.
"""

import os
import sys
from pathlib import Path

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSettings, QUrl
from PyQt6.QtGui import QFont, QFontDatabase, QPixmap, QDesktopServices
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QRadioButton,
    QTextEdit, QGroupBox, QFileDialog, QMessageBox,
    QProgressBar, QButtonGroup, QTabWidget, QCheckBox,
    QStatusBar, QGridLayout, QFrame, QSplitter, QSizePolicy,
)

from flash_encrypt_core import (
    VERSION, APP_NAME, COMPANY, PROJECT_DIR, BUNDLED_TOOL_DIR, ARDUINO_HINT,
    TAGLINE, PROJECT_URL, DONATE_URL,
    DEFAULT_FLASH_BAUD, DEFAULT_CHIP, chip_choices, chip_profile,
    default_key_path, ensure_writable_key_path,
    generate_key_file, burn_key_to_efuse, encrypt_bins, flash_bins,
    flash_encrypt_on_device, flash_plaintext, validate_firmware_set,
    scan_arduino_bins, run_efuse_summary, read_chip_info, timestamp,
)

# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------
COLORS = {
    "bg_dark": "#060d18",
    "bg_primary": "#0c1829",
    "bg_secondary": "#122238",
    "bg_tertiary": "#1a2f4a",
    "bg_elevated": "#1e3554",
    "accent_cyan": "#00d4ff",
    "accent_blue": "#0088cc",
    "accent_green": "#00e676",
    "text_primary": "#e8f0f8",
    "text_secondary": "#8aa4c0",
    "text_muted": "#5a7088",
    "warning": "#ffb020",
    "error": "#ff4d6a",
    "success": "#00e676",
    "border": "#243a55",
    "border_focus": "#00d4ff",
}

FONT_FAMILY = "Oxanium"


def load_app_fonts():
    """Load bundled Oxanium fonts; return resolved family name."""
    fonts_dir = PROJECT_DIR / "fonts"
    last_id = -1
    if fonts_dir.is_dir():
        for ttf in sorted(fonts_dir.glob("*.ttf")):
            font_id = QFontDatabase.addApplicationFont(str(ttf))
            if font_id >= 0:
                last_id = font_id

    if last_id >= 0:
        families = QFontDatabase.applicationFontFamilies(last_id)
        if families:
            return families[0]

    if "Oxanium" in QFontDatabase.families():
        return "Oxanium"

    return "Segoe UI"


def list_serial_ports():
    """Return unique serial port names."""
    ports = []
    try:
        if os.name == "nt":
            import serial.tools.list_ports
            ports = [p.device for p in serial.tools.list_ports.comports()]
        else:
            for candidate in ("/dev/ttyUSB0", "/dev/ttyUSB1", "/dev/ttyACM0", "/dev/ttyACM1"):
                if os.path.exists(candidate):
                    ports.append(candidate)
    except Exception:
        pass

    seen = set()
    unique = []
    for port in ports:
        if port not in seen:
            seen.add(port)
            unique.append(port)

    return unique


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
class Worker(QThread):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool, str)

    def __init__(self, operation, params):
        super().__init__()
        self.operation = operation
        self.params = params

    def log(self, msg):
        self.log_signal.emit(f"[{timestamp()}] {msg}")

    def run(self):
        try:
            handlers = {
                "generate_key": self._do_generate_key,
                "burn_key": self._do_burn_key,
                "encrypt": self._do_encrypt,
                "flash": self._do_flash,
                "flash_plain": self._do_flash_plain,
                "encrypt_flash": self._do_encrypt_flash,
                "full": self._do_full,
                "chip_info": self._do_chip_info,
            }
            handler = handlers.get(self.operation)
            if not handler:
                self.finished_signal.emit(False, f"Unknown operation: {self.operation}")
                return
            handler()
        except PermissionError as exc:
            msg = str(exc)
            self.log(f"PERMISSION DENIED: {msg}")
            if "COM" in msg.upper() or "tty" in msg.lower() or "port" in msg.lower():
                hint = (
                    "Serial port is locked. Close Arduino Serial Monitor, "
                    "PuTTY, or any other tool using that COM port, then retry."
                )
            else:
                hint = (
                    "Cannot write that path. If you selected a folder, include a "
                    "filename ending in .bin (e.g. "
                    r"C:\Users\...\Documents\bps_firmware_keys\flash_encryption_key.bin"
                    "). Or use Browse and pick a file name."
                )
            self.log(hint)
            self.finished_signal.emit(False, hint)
        except Exception as exc:
            self.log(f"FATAL ERROR: {exc}")
            self.finished_signal.emit(False, str(exc))

    def _tool_paths(self):
        return {
            "esptool_path": self.params.get("esptool_path") or None,
            "espefuse_path": self.params.get("espefuse_path") or None,
        }

    def _do_generate_key(self):
        self.log("=" * 60)
        self.log("GENERATING ENCRYPTION KEY")
        self.log("=" * 60)
        requested = self.params.get("key_file") or default_key_path()
        output = generate_key_file(requested, log_fn=self.log)
        # Pass the actual path back so the UI can update the Key File field.
        self.finished_signal.emit(True, f"Key generated: {output}")
        self.params["key_file"] = output

    def _do_burn_key(self):
        self.log("=" * 60)
        self.log(f"BURNING KEY TO EFUSE ON {self.params['port']}")
        self.log("=" * 60)
        ok = burn_key_to_efuse(
            self.params["key_file"], self.params["port"], log_fn=self.log,
            uart_disable=self.params.get("uart_disable", False),
            jtag_disable=self.params.get("jtag_disable", False),
            espefuse_path=self.params.get("espefuse_path"),
            chip=self.params.get("chip"),
        )
        self.finished_signal.emit(ok, "Key burned successfully" if ok else "Failed to burn key")

    def _do_encrypt(self):
        self.log("=" * 60)
        self.log("ENCRYPTING BINARY FILES")
        self.log("=" * 60)
        count = encrypt_bins(
            self.params["key_file"],
            bootloader=self.params.get("bootloader") or None,
            partition=self.params.get("partition") or None,
            app=self.params.get("app") or None,
            boot_app0=self.params.get("boot_app0") or None,
            log_fn=self.log,
            esptool_path=self.params.get("esptool_path"),
            chip=self.params.get("chip"),
        )
        if count == 0:
            self.finished_signal.emit(False, "No files were encrypted")
        else:
            self.finished_signal.emit(True, f"Encrypted {count} file(s)")

    def _do_flash(self):
        self.log("=" * 60)
        self.log(f"FLASHING PRE-ENCRYPTED FILES TO {self.params['port']}")
        self.log("=" * 60)
        if not validate_firmware_set(
            self.params.get("bootloader"), self.params.get("partition"),
            self.params.get("app"), boot_app0=self.params.get("boot_app0"),
            require_all=True, log_fn=self.log,
        ):
            self.finished_signal.emit(False, "Missing required firmware binaries")
            return
        count = flash_bins(
            self.params["port"],
            bootloader=self.params.get("bootloader") or None,
            partition=self.params.get("partition") or None,
            app=self.params.get("app") or None,
            boot_app0=self.params.get("boot_app0") or None,
            encrypted=True,
            log_fn=self.log,
            esptool_path=self.params.get("esptool_path"),
            baud=self.params.get("baud"),
            chip=self.params.get("chip"),
        )
        if count == 0:
            self.finished_signal.emit(False, "Flash failed — ensure .enc.bin files exist")
        else:
            self.finished_signal.emit(True, f"Flashed {count} encrypted image(s)")

    def _do_flash_plain(self):
        self.log("=" * 60)
        self.log(f"FLASHING PLAINTEXT FIRMWARE TO {self.params['port']}")
        self.log("=" * 60)
        self.log("No encryption — verify the firmware boots before encrypting.")
        self.log("")
        count = flash_plaintext(
            self.params["port"],
            bootloader=self.params.get("bootloader") or None,
            partition=self.params.get("partition") or None,
            app=self.params.get("app") or None,
            boot_app0=self.params.get("boot_app0") or None,
            log_fn=self.log,
            esptool_path=self.params.get("esptool_path"),
            baud=self.params.get("baud"),
            chip=self.params.get("chip"),
        )
        if count == 0:
            self.finished_signal.emit(False, "Plaintext flash failed — check firmware files and port")
        else:
            self.finished_signal.emit(True, f"Flashed {count} plaintext image(s) — chip should boot now")

    def _do_encrypt_flash(self):
        self.log("=" * 60)
        self.log("FLASH WITH ON-CHIP ENCRYPTION (RECOMMENDED)")
        self.log("=" * 60)
        self.log("Plaintext .bin files are encrypted by the chip during download.")
        self.log("")
        count = flash_encrypt_on_device(
            self.params["port"],
            bootloader=self.params.get("bootloader") or None,
            partition=self.params.get("partition") or None,
            app=self.params.get("app") or None,
            boot_app0=self.params.get("boot_app0") or None,
            key_file=self.params.get("key_file"),
            log_fn=self.log,
            esptool_path=self.params.get("esptool_path"),
            espefuse_path=self.params.get("espefuse_path"),
            uart_disable=self.params.get("uart_disable", False),
            jtag_disable=self.params.get("jtag_disable", False),
            baud=self.params.get("baud"),
            chip=self.params.get("chip"),
        )
        if count == 0:
            self.finished_signal.emit(False, "Flash failed — check firmware files and key file")
        else:
            self.finished_signal.emit(True, f"Flashed and encrypted {count} image(s) on device")

    def _do_full(self):
        self.log("=" * 60)
        self.log("FULL FLASH ENCRYPTION PROCESS")
        self.log("=" * 60)

        key = self.params.get("key_file") or default_key_path()
        port = self.params["port"]

        self.log("")
        self.log("STEP 1/4: KEY GENERATION")
        if not key or not os.path.isfile(key):
            key = default_key_path()
            generate_key_file(key, log_fn=self.log)
        else:
            self.log(f"Using existing key: {key}")

        self.log("")
        self.log("STEP 2/4: BURN KEY TO EFUSE")
        if not burn_key_to_efuse(
            key, port, log_fn=self.log,
            uart_disable=self.params.get("uart_disable", False),
            jtag_disable=self.params.get("jtag_disable", False),
            espefuse_path=self.params.get("espefuse_path"),
            chip=self.params.get("chip"),
        ):
            self.finished_signal.emit(False, "Failed during key burn step")
            return

        self.log("")
        self.log("STEP 3/4: CREATE OFFLINE .enc.bin BACKUPS")
        encrypt_bins(
            key,
            bootloader=self.params.get("bootloader") or None,
            partition=self.params.get("partition") or None,
            app=self.params.get("app") or None,
            boot_app0=self.params.get("boot_app0") or None,
            log_fn=self.log,
            esptool_path=self.params.get("esptool_path"),
            chip=self.params.get("chip"),
        )

        self.log("")
        self.log("STEP 4/4: FLASH WITH ON-CHIP ENCRYPTION")
        flashed = flash_encrypt_on_device(
            port,
            bootloader=self.params.get("bootloader") or None,
            partition=self.params.get("partition") or None,
            app=self.params.get("app") or None,
            boot_app0=self.params.get("boot_app0") or None,
            key_file=key,
            log_fn=self.log,
            esptool_path=self.params.get("esptool_path"),
            espefuse_path=self.params.get("espefuse_path"),
            uart_disable=self.params.get("uart_disable", False),
            jtag_disable=self.params.get("jtag_disable", False),
            baud=self.params.get("baud"),
            chip=self.params.get("chip"),
        )
        if flashed == 0:
            self.finished_signal.emit(False, "Flash step failed — all 4 binaries required")
            return

        self.log("")
        self.log("=" * 60)
        self.log("PROCESS COMPLETE")
        self.log("=" * 60)
        self.log(f"Key location: {key}")
        self.log("IMPORTANT: Backup your encryption key!")

        run_efuse_summary(port, log_fn=self.log,
                          espefuse_path=self.params.get("espefuse_path"),
                          chip=self.params.get("chip"))
        self.finished_signal.emit(True, "Full process completed")

    def _do_chip_info(self):
        port = self.params["port"]
        label = chip_profile(self.params.get("chip"))["label"]
        self.log("=" * 60)
        self.log(f"{label} CHIP INFORMATION — {port}")
        self.log("=" * 60)
        ok = read_chip_info(
            port,
            log_fn=self.log,
            esptool_path=self.params.get("esptool_path"),
            chip=self.params.get("chip"),
        )
        self.finished_signal.emit(ok, "Chip info retrieved" if ok else "Failed to read chip info")


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self, font_family):
        super().__init__()
        self.font_family = font_family
        self.settings = QSettings(COMPANY, APP_NAME)
        self.worker = None

        self.setWindowTitle(f"{APP_NAME} v{VERSION} — {COMPANY}")
        self.setMinimumSize(1100, 1080)
        self.resize(1240, 1180)

        self._build_ui()
        self._restore_settings()
        self._populate_all_ports()
        self._show_safety_notice_once()

    def _build_ui(self):
        self.setStyleSheet(self._stylesheet())

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(20, 16, 20, 12)
        root.setSpacing(14)

        root.addWidget(self._header())
        root.addWidget(self._tabs(), 1)
        self._statusbar()
        self._clear_label_backgrounds(central)

    def _clear_label_backgrounds(self, root):
        """Prevent Windows from painting opaque boxes behind labels."""
        for label in root.findChildren(QLabel):
            label.setAutoFillBackground(False)

    def _stylesheet(self):
        f = self.font_family
        c = COLORS
        return f"""
        QMainWindow, QWidget {{
            background-color: {c['bg_dark']};
            color: {c['text_primary']};
            font-family: '{f}', 'Segoe UI', sans-serif;
            font-size: 10pt;
        }}
        QLabel {{
            background-color: transparent;
            color: {c['text_primary']};
            border: none;
        }}
        QFrame#card {{
            background-color: {c['bg_primary']};
            border: 1px solid {c['border']};
            border-radius: 10px;
        }}
        QTabWidget::pane {{
            border: 1px solid {c['border']};
            border-radius: 10px;
            background-color: {c['bg_primary']};
            top: -1px;
        }}
        QTabBar::tab {{
            background-color: {c['bg_secondary']};
            color: {c['text_secondary']};
            padding: 11px 28px;
            margin-right: 3px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            font-family: '{f}', sans-serif;
            font-weight: 600;
            letter-spacing: 0.5px;
        }}
        QTabBar::tab:selected {{
            background-color: {c['bg_primary']};
            color: {c['accent_cyan']};
            border-bottom: 2px solid {c['accent_cyan']};
        }}
        QTabBar::tab:hover:!selected {{
            background-color: {c['bg_tertiary']};
            color: {c['text_primary']};
        }}
        QGroupBox {{
            background-color: {c['bg_secondary']};
            border: 1px solid {c['border']};
            border-radius: 10px;
            margin-top: 18px;
            padding: 18px 14px 14px 14px;
            font-family: '{f}', sans-serif;
            font-weight: 600;
        }}
        QGroupBox::title {{
            color: {c['accent_cyan']};
            subcontrol-origin: margin;
            left: 16px;
            padding: 0 8px;
            background-color: transparent;
        }}
        QPushButton {{
            background-color: {c['bg_elevated']};
            color: {c['text_primary']};
            border: 1px solid {c['border']};
            border-radius: 7px;
            padding: 10px 18px;
            font-family: '{f}', sans-serif;
            font-weight: 600;
            min-height: 18px;
        }}
        QPushButton:hover {{
            background-color: {c['bg_tertiary']};
            border-color: {c['accent_cyan']};
            color: {c['accent_cyan']};
        }}
        QPushButton:pressed {{
            background-color: {c['accent_cyan']};
            color: {c['bg_dark']};
        }}
        QPushButton:disabled {{
            background-color: {c['bg_secondary']};
            color: {c['text_muted']};
            border-color: {c['bg_secondary']};
        }}
        QPushButton#primary {{
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 {c['accent_cyan']}, stop:1 {c['accent_green']});
            color: {c['bg_dark']};
            border: none;
            font-weight: 700;
        }}
        QPushButton#primary:hover {{
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #33ddff, stop:1 #33ee99);
        }}
        QPushButton#success {{
            background-color: {c['success']};
            color: {c['bg_dark']};
            border: none;
            font-weight: 700;
        }}
        QPushButton#ghost {{
            background-color: transparent;
            border: 1px solid {c['border']};
            color: {c['text_secondary']};
        }}
        QLineEdit, QComboBox {{
            background-color: {c['bg_secondary']};
            color: {c['text_primary']};
            border: 1px solid {c['border']};
            border-radius: 7px;
            padding: 9px 12px;
            selection-background-color: {c['accent_cyan']};
        }}
        QLineEdit:focus, QComboBox:focus {{
            border: 1px solid {c['border_focus']};
        }}
        QComboBox::drop-down {{
            border: none;
            width: 24px;
        }}
        QComboBox::down-arrow {{
            width: 0; height: 0;
            border-left: 5px solid transparent;
            border-right: 5px solid transparent;
            border-top: 6px solid {c['accent_cyan']};
            margin-right: 8px;
        }}
        QRadioButton, QCheckBox {{
            spacing: 10px;
            color: {c['text_primary']};
            background-color: transparent;
            min-height: 28px;
            padding: 4px 0;
        }}
        QRadioButton::indicator, QCheckBox::indicator {{
            width: 16px; height: 16px;
            border: 2px solid {c['accent_cyan']};
            border-radius: 8px;
            background: transparent;
        }}
        QCheckBox::indicator {{ border-radius: 4px; }}
        QRadioButton::indicator:checked, QCheckBox::indicator:checked {{
            background-color: {c['accent_cyan']};
        }}
        QTextEdit, QTextEdit#log {{
            background-color: {c['bg_secondary']};
            color: {c['text_primary']};
            border: 1px solid {c['border']};
            border-radius: 8px;
            font-family: 'Consolas', 'Courier New', monospace;
            font-size: 9pt;
            padding: 10px;
        }}
        QProgressBar {{
            background-color: {c['bg_secondary']};
            border: 1px solid {c['border']};
            border-radius: 6px;
            text-align: center;
            color: {c['text_primary']};
            min-height: 22px;
        }}
        QProgressBar::chunk {{
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 {c['accent_cyan']}, stop:1 {c['accent_green']});
            border-radius: 5px;
        }}
        QLabel#title {{
            color: {c['accent_cyan']};
            font-size: 20pt;
            font-weight: 700;
            letter-spacing: 1px;
            background-color: transparent;
        }}
        QLabel#subtitle {{
            color: {c['text_secondary']};
            font-size: 10pt;
            background-color: transparent;
        }}
        QLabel#badge {{
            color: {c['accent_green']};
            background-color: {c['bg_tertiary']};
            border: 1px solid {c['border']};
            border-radius: 12px;
            padding: 4px 12px;
            font-size: 9pt;
            font-weight: 600;
        }}
        QStatusBar {{
            background-color: {c['bg_secondary']};
            color: {c['text_secondary']};
            border-top: 1px solid {c['border']};
        }}
        """

    def _header(self):
        frame = QFrame()
        frame.setObjectName("card")
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(20, 16, 20, 16)

        logo = QLabel()
        logo_path = PROJECT_DIR / "assets" / "cipherfuse_logo.png"
        if not logo_path.is_file():
            logo_path = PROJECT_DIR / "assets" / "autoponix_logo.png"
        if logo_path.is_file():
            logo.setPixmap(QPixmap(str(logo_path)).scaled(
                64, 64, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
        else:
            logo.setText("CF")
            logo.setStyleSheet(
                f"color: {COLORS['accent_cyan']}; font-size: 28pt; font-weight: 700;"
            )
        logo.setFixedSize(72, 72)
        logo.setStyleSheet("background: transparent; border: none;")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo)

        titles = QVBoxLayout()
        titles.setSpacing(4)
        title = QLabel(APP_NAME)
        title.setObjectName("title")
        subtitle = QLabel(TAGLINE + "  ·  ESP32, S2, S3, C3, C6, H2, P4")
        subtitle.setObjectName("subtitle")
        badge = QLabel(f"v{VERSION}  ·  free  ·  GPL-3.0")
        badge.setObjectName("badge")
        titles.addWidget(title)
        titles.addWidget(subtitle)
        titles.addWidget(badge)
        layout.addLayout(titles)
        layout.addStretch()

        status_box = QVBoxLayout()
        status_box.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_dot = QLabel("●")
        self.status_dot.setStyleSheet(
            f"color: {COLORS['success']}; font-size: 22pt; background: transparent;"
        )
        self.status_text = QLabel("Ready")
        self.status_text.setObjectName("subtitle")
        status_box.addWidget(self.status_dot, alignment=Qt.AlignmentFlag.AlignCenter)
        status_box.addWidget(self.status_text, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addLayout(status_box)

        about_btn = QPushButton("About")
        about_btn.setObjectName("ghost")
        about_btn.clicked.connect(self._show_about)
        layout.addWidget(about_btn, alignment=Qt.AlignmentFlag.AlignVCenter)

        return frame

    def _tabs(self):
        self.tabs = QTabWidget()
        self.tabs.addTab(self._operations_tab(), "Operations")
        self.tabs.addTab(self._firmware_tab(), "Firmware")
        self.tabs.addTab(self._settings_tab(), "Settings")
        self.tabs.addTab(self._help_tab(), "Help")
        self.chip_combo.currentIndexChanged.connect(self._on_chip_changed)
        self._on_chip_changed()
        return self.tabs

    def _on_chip_changed(self, *_):
        """Update the bootloader address label to match the selected chip."""
        bl = chip_profile(self.chip_combo.currentData())["bootloader_addr"]
        self.boot_label.setText(f"Bootloader  {hex(bl)}")

    def _operations_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)

        ops = QGroupBox("Select Operation")
        ops.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
        ops_layout = QVBoxLayout(ops)
        ops_layout.setSpacing(10)
        self.op_group = QButtonGroup(self)
        self.op_modes = [
            ("Generate Key", "generate_key", "Create a new 256-bit AES encryption key"),
            ("Burn Key to Efuse", "burn_key", "Program the key into the chip (permanent)"),
            ("Encrypt Binaries", "encrypt", "Encrypt .bin files with your key"),
            ("Flash Encrypted", "flash", "Write encrypted files to device flash"),
            ("Full Process", "full", "Generate key, burn, encrypt, and flash in one run"),
        ]
        for idx, (label, mode, desc) in enumerate(self.op_modes):
            rb = QRadioButton(label)
            rb.setMinimumHeight(32)
            rb.setChecked(mode == "full")
            self.op_group.addButton(rb, idx)
            row = QHBoxLayout()
            row.setContentsMargins(0, 2, 0, 2)
            row.addWidget(rb)
            hint = QLabel(desc)
            hint.setMinimumHeight(32)
            hint.setStyleSheet(f"color: {COLORS['text_muted']}; background: transparent;")
            row.addWidget(hint, 1)
            ops_layout.addLayout(row)

        conn = QGroupBox("Connection")
        conn_grid = QGridLayout(conn)
        conn_grid.addWidget(QLabel("Target Chip"), 0, 0)
        self.chip_combo = QComboBox()
        for chip_id, label in chip_choices():
            self.chip_combo.addItem(label, chip_id)
        self._select_chip(DEFAULT_CHIP)
        self.chip_combo.setToolTip(
            "Select your ESP32 variant. This sets the bootloader offset and the "
            "flash-encryption scheme (XTS-AES for S2/S3/C-series, AES-256 for the "
            "original ESP32)."
        )
        conn_grid.addWidget(self.chip_combo, 0, 1, 1, 2)

        conn_grid.addWidget(QLabel("Serial Port"), 1, 0)
        self.port_combo = QComboBox()
        self.port_combo.setEditable(True)
        conn_grid.addWidget(self.port_combo, 1, 1)
        refresh = QPushButton("Refresh")
        refresh.setObjectName("ghost")
        refresh.clicked.connect(self._populate_all_ports)
        conn_grid.addWidget(refresh, 1, 2)

        self.chip_info_btn = QPushButton("Read Chip Info")
        self.chip_info_btn.setObjectName("ghost")
        self.chip_info_btn.clicked.connect(self._read_chip_info)
        conn_grid.addWidget(self.chip_info_btn, 2, 1, 1, 2)

        key_grp = QGroupBox("Encryption Key")
        key_grid = QGridLayout(key_grp)
        key_grid.addWidget(QLabel("Key File"), 0, 0)
        self.key_edit = QLineEdit(default_key_path())
        key_grid.addWidget(self.key_edit, 0, 1)
        browse_key = QPushButton("Browse")
        browse_key.clicked.connect(self._browse_key)
        key_grid.addWidget(browse_key, 0, 2)
        gen_btn = QPushButton("Generate New Key")
        gen_btn.setObjectName("primary")
        gen_btn.clicked.connect(self._quick_generate_key)
        key_grid.addWidget(gen_btn, 1, 1, 1, 2)

        self.execute_btn = QPushButton("Execute Selected Operation")
        self.execute_btn.setObjectName("primary")
        self.execute_btn.setMinimumHeight(48)
        self.execute_btn.clicked.connect(self._execute_operation)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setTextVisible(False)

        log_grp = QGroupBox("Output Log")
        log_layout = QVBoxLayout(log_grp)
        self.log_area = QTextEdit()
        self.log_area.setObjectName("log")
        self.log_area.setReadOnly(True)
        self.log_area.setMinimumHeight(160)
        log_layout.addWidget(self.log_area)
        clear = QPushButton("Clear Log")
        clear.setObjectName("ghost")
        clear.clicked.connect(self.log_area.clear)
        log_layout.addWidget(clear, alignment=Qt.AlignmentFlag.AlignRight)

        layout.addWidget(ops)
        layout.addWidget(conn)
        layout.addWidget(key_grp)
        layout.addWidget(self.execute_btn)
        layout.addWidget(self.progress)
        layout.addWidget(log_grp, 1)
        return tab

    def _firmware_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)

        files = QGroupBox("Firmware Binaries (Arduino: all 4 required)")
        grid = QGridLayout(files)
        self.boot_edit = QLineEdit()
        self.boot_edit.setPlaceholderText("Sketch.ino.bootloader.bin")
        self.part_edit = QLineEdit()
        self.part_edit.setPlaceholderText("Sketch.ino.partitions.bin")
        self.boot_app0_edit = QLineEdit()
        self.boot_app0_edit.setPlaceholderText("boot_app0.bin (required for OTA schemes @ 0xE000)")
        self.app_edit = QLineEdit()
        self.app_edit.setPlaceholderText("Sketch.ino.bin")

        self.boot_label = QLabel("Bootloader  0x1000")
        for row, (label, widget) in enumerate([
            (self.boot_label, self.boot_edit),
            (QLabel("Partition   0x8000"), self.part_edit),
            (QLabel("boot_app0   0xE000"), self.boot_app0_edit),
            (QLabel("Application 0x10000"), self.app_edit),
        ]):
            grid.addWidget(label, row, 0)
            grid.addWidget(widget, row, 1)
            btn = QPushButton("Browse")
            btn.clicked.connect(lambda _, w=widget: self._browse(w, "BIN Files (*.bin)"))
            grid.addWidget(btn, row, 2)

        actions = QHBoxLayout()
        scan = QPushButton("Scan Arduino Build Folder")
        scan.clicked.connect(self._scan_bins)
        clear = QPushButton("Clear")
        clear.setObjectName("ghost")
        clear.clicked.connect(self._clear_bins)
        actions.addWidget(scan)
        actions.addWidget(clear)
        actions.addStretch()
        grid.addLayout(actions, 4, 0, 1, 3)

        btn_row = QHBoxLayout()
        self.flash_plain_btn = QPushButton("Flash Plaintext (Test)")
        self.flash_plain_btn.setObjectName("success")
        self.flash_plain_btn.setToolTip(
            "Flash unencrypted firmware to verify the build boots before encrypting"
        )
        self.flash_plain_btn.clicked.connect(lambda: self._run_firmware_op("flash_plain"))
        self.encrypt_btn = QPushButton("Encrypt Offline")
        self.encrypt_btn.setObjectName("primary")
        self.encrypt_btn.clicked.connect(lambda: self._run_firmware_op("encrypt"))
        self.flash_btn = QPushButton("Flash .enc.bin")
        self.flash_btn.setObjectName("success")
        self.flash_btn.clicked.connect(lambda: self._run_firmware_op("flash"))
        self.enc_flash_btn = QPushButton("Flash & Encrypt")
        self.enc_flash_btn.setObjectName("primary")
        self.enc_flash_btn.setToolTip(
            "Recommended: flash plaintext .bin files; chip encrypts during download"
        )
        self.enc_flash_btn.clicked.connect(lambda: self._run_firmware_op("encrypt_flash"))
        for btn in (self.flash_plain_btn, self.encrypt_btn, self.flash_btn, self.enc_flash_btn):
            btn.setMinimumHeight(44)
            btn_row.addWidget(btn)

        self.fw_progress = QProgressBar()
        self.fw_progress.setVisible(False)
        self.fw_progress.setTextVisible(False)

        log_grp = QGroupBox("Firmware Log")
        log_layout = QVBoxLayout(log_grp)
        self.fw_log = QTextEdit()
        self.fw_log.setObjectName("log")
        self.fw_log.setReadOnly(True)
        self.fw_log.setMinimumHeight(200)
        log_layout.addWidget(self.fw_log)

        layout.addWidget(files)
        layout.addLayout(btn_row)
        layout.addWidget(self.fw_progress)
        layout.addWidget(log_grp, 1)
        return tab

    def _settings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        gen = QGroupBox("General")
        gen_layout = QVBoxLayout(gen)
        self.auto_detect = QCheckBox("Auto-detect serial ports on startup")
        self.auto_detect.setChecked(True)
        gen_layout.addWidget(self.auto_detect)

        baud_row = QHBoxLayout()
        baud_row.addWidget(QLabel("Flash baud"))
        self.baud_combo = QComboBox()
        self.baud_combo.addItems(["115200", "460800", "921600"])
        self.baud_combo.setCurrentText(str(DEFAULT_FLASH_BAUD))
        self.baud_combo.setToolTip(
            "Keep at 115200 for ESP32-S2/S3 native USB (USB-OTG). Higher baud causes "
            "the USB port to re-enumerate mid-flash ('Cannot configure port' error).\n"
            "Only raise this if you flash via a USB-UART bridge (CP2102/CH340)."
        )
        baud_row.addWidget(self.baud_combo)
        baud_row.addWidget(QLabel("(use 115200 for native USB / USB-OTG)"))
        baud_row.addStretch()
        gen_layout.addLayout(baud_row)

        sec = QGroupBox("Security Options")
        sec_layout = QVBoxLayout(sec)
        self.uart_disable = QCheckBox("Disable UART download mode after burn (DIS_DOWNLOAD_MODE)")
        self.jtag_disable = QCheckBox("Disable JTAG permanently after burn (HARD_DIS_JTAG)")
        sec_layout.addWidget(self.uart_disable)
        sec_layout.addWidget(self.jtag_disable)

        paths = QGroupBox("Tool Paths")
        path_grid = QGridLayout(paths)
        self.esptool_path = QLineEdit(str(BUNDLED_TOOL_DIR))
        self.espefuse_path = QLineEdit(str(BUNDLED_TOOL_DIR))
        path_grid.addWidget(QLabel("esptool dir"), 0, 0)
        path_grid.addWidget(self.esptool_path, 0, 1)
        b1 = QPushButton("Browse")
        b1.clicked.connect(lambda: self._browse_dir(self.esptool_path))
        path_grid.addWidget(b1, 0, 2)
        path_grid.addWidget(QLabel("espefuse dir"), 1, 0)
        path_grid.addWidget(self.espefuse_path, 1, 1)
        b2 = QPushButton("Browse")
        b2.clicked.connect(lambda: self._browse_dir(self.espefuse_path))
        path_grid.addWidget(b2, 1, 2)

        reset = QPushButton("Reset to Defaults")
        reset.setObjectName("ghost")
        reset.clicked.connect(self._reset_settings)

        layout.addWidget(gen)
        layout.addWidget(sec)
        layout.addWidget(paths)
        layout.addWidget(reset)
        layout.addStretch()
        return tab

    def _help_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        help_text = QTextEdit()
        help_text.setObjectName("log")
        help_text.setReadOnly(True)
        help_text.setHtml(f"""
        <html><body style="font-family:{self.font_family},sans-serif;color:{COLORS['text_primary']};">
        <h2 style="color:{COLORS['accent_cyan']};">Select your chip first</h2>
        <p>On the <b>Operations</b> tab choose your <b>Target Chip</b>. This sets the
        bootloader offset and the flash-encryption scheme automatically:</p>
        <ul>
          <li><b>ESP32 / ESP32-S2</b> → bootloader @ <code>0x1000</code></li>
          <li><b>ESP32-S3 / C2 / C3 / C6 / H2</b> → bootloader @ <code>0x0</code></li>
          <li><b>ESP32-P4</b> → bootloader @ <code>0x2000</code></li>
        </ul>
        <p>Original <b>ESP32</b> uses the AES-256 (FLASH_CRYPT_CONFIG) scheme; all newer
        chips use XTS-AES with a key in BLOCK_KEY0.</p>
        <h2 style="color:{COLORS['accent_cyan']};">Arduino Workflow</h2>
        <p>After compiling in Arduino IDE, flash all four binaries from the build folder
        (bootloader offset depends on the chip you selected):</p>
        <ul>
          <li><code>Sketch.ino.bootloader.bin</code> → bootloader offset</li>
          <li><code>Sketch.ino.partitions.bin</code> → 0x8000</li>
          <li><code>boot_app0.bin</code> → 0xE000 (OTA slot selector — required or app won't boot)</li>
          <li><code>Sketch.ino.bin</code> → 0x10000</li>
        </ul>
        <p><b>Recommended order:</b></p>
        <ol>
          <li><b>Flash Plaintext (Test)</b> — flash unencrypted firmware first and confirm the chip boots.</li>
          <li>Generate &amp; burn the encryption key (Operations tab).</li>
          <li><b>Flash &amp; Encrypt</b> — encrypts on-chip during download.</li>
        </ol>
        <p><b>Flash &amp; Encrypt</b> requires the encryption key in eFuse. Set the key file on Operations —
        the tool auto-burns it if needed.</p>
        <p style="color:{COLORS['warning']};">Flashing without boot_app0.bin leaves otadata erased (0xFF) — the bootloader cannot select the app slot.</p>
        <h2 style="color:{COLORS['accent_cyan']};">Flash Addresses</h2>
        <table cellpadding="6">
          <tr><td>Bootloader</td><td><code>0x0 / 0x1000 / 0x2000</code> (chip-specific)</td></tr>
          <tr><td>Partition</td><td><code>0x8000</code></td></tr>
          <tr><td>OTA data (boot_app0)</td><td><code>0xE000</code></td></tr>
          <tr><td>Application</td><td><code>0x10000</code></td></tr>
        </table>
        <h2 style="color:{COLORS['accent_cyan']};">CLI</h2>
        <pre style="color:{COLORS['accent_green']};">
python esp32_flash_encrypt_cli_v3.py generate_key
python esp32_flash_encrypt_cli_v3.py full -p COM3 --chip esp32s3 -k key.bin -a app.bin
        </pre>
        <h2 style="color:{COLORS['accent_cyan']};">Free software</h2>
        <p>{APP_NAME} is free under GPL-3.0. If it saves you a board, a donation helps keep it maintained:
        <a href="{DONATE_URL}">{DONATE_URL}</a></p>
        <p>{APP_NAME} is not affiliated with Espressif Systems. ESP32 is a trademark of Espressif Systems.</p>
        <p>{APP_NAME} · v{VERSION}</p>
        </body></html>
        """)
        layout.addWidget(help_text)
        return tab

    def _statusbar(self):
        bar = QStatusBar()
        self.setStatusBar(bar)
        bar.showMessage(f"Ready  ·  {COMPANY}  ·  v{VERSION}")

    def _browse(self, field, filt):
        path, _ = QFileDialog.getOpenFileName(self, "Select File", "", filt)
        if path:
            field.setText(path)

    def _browse_key(self):
        """Pick a key *file* path (not a folder). Saves under Documents by default."""
        start = self.key_edit.text().strip() or default_key_path()
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Choose Key File Location",
            start,
            "Key Files (*.bin);;All Files (*)",
        )
        if not path:
            return
        if not path.lower().endswith(".bin"):
            path += ".bin"
        self.key_edit.setText(path)

    def _browse_dir(self, field):
        path = QFileDialog.getExistingDirectory(self, "Select Tool Directory")
        if path:
            field.setText(path)

    def _populate_all_ports(self):
        ports = list_serial_ports()
        current = self.port_combo.currentText()
        self.port_combo.clear()
        if ports:
            self.port_combo.addItems(ports)
            if current in ports:
                self.port_combo.setCurrentText(current)
        else:
            self.port_combo.setCurrentText("")

    def _select_chip(self, chip_id):
        idx = self.chip_combo.findData(chip_id)
        if idx >= 0:
            self.chip_combo.setCurrentIndex(idx)

    def _params(self):
        return {
            "key_file": self.key_edit.text().strip(),
            "port": self.port_combo.currentText().strip(),
            "chip": self.chip_combo.currentData(),
            "bootloader": self.boot_edit.text().strip(),
            "partition": self.part_edit.text().strip(),
            "boot_app0": self.boot_app0_edit.text().strip(),
            "app": self.app_edit.text().strip(),
            "baud": self.baud_combo.currentText().strip(),
            "esptool_path": self.esptool_path.text().strip(),
            "espefuse_path": self.espefuse_path.text().strip(),
            "uart_disable": self.uart_disable.isChecked(),
            "jtag_disable": self.jtag_disable.isChecked(),
        }

    def _selected_mode(self):
        idx = self.op_group.checkedId()
        if idx < 0:
            return None
        return self.op_modes[idx][1]

    def _validate(self, mode, params):
        needs_firmware = mode in ("flash", "flash_plain", "encrypt_flash", "full", "encrypt")
        if needs_firmware:
            if not validate_firmware_set(
                params.get("bootloader"), params.get("partition"), params.get("app"),
                boot_app0=params.get("boot_app0"), require_all=True,
            ):
                return (
                    "All four binaries are required (bootloader, partition, boot_app0, app).\n\n"
                    + ARDUINO_HINT
                )

        if mode in ("burn_key", "encrypt", "full"):
            if not params["key_file"]:
                return "Please specify a key file"
            if mode != "full" and not os.path.isfile(params["key_file"]):
                return f"Key file not found: {params['key_file']}"

        if mode == "encrypt_flash" and not params.get("key_file"):
            return "Set the encryption key file on the Operations tab (needed to burn key to eFuse)"

        if mode in ("burn_key", "flash", "flash_plain", "full", "encrypt_flash"):
            if not params["port"]:
                return "Please select a serial port"

        if mode == "flash":
            for label, path in [
                ("bootloader", params["bootloader"]),
                ("partition", params["partition"]),
                ("boot_app0", params.get("boot_app0")),
                ("application", params["app"]),
            ]:
                if not path:
                    continue
                enc = path.replace(".bin", ".enc.bin")
                if not os.path.isfile(enc):
                    return f"Missing encrypted file for {label}: {enc}\nRun 'Encrypt Offline' first."

        return None

    def _start_worker(self, mode, params, log_widget, progress, buttons):
        err = self._validate(mode, params)
        if err:
            QMessageBox.warning(self, "Validation", err)
            return

        self._active_log = log_widget
        self._active_progress = progress
        self._active_buttons = buttons

        for btn in buttons:
            btn.setEnabled(False)
        progress.setVisible(True)
        progress.setRange(0, 0)

        self._set_status("Running", COLORS["warning"])
        log_widget.clear()
        log_widget.append(f"[{timestamp()}] Starting: {mode}")

        self.worker = Worker(mode, params)
        self.worker.log_signal.connect(log_widget.append)
        self.worker.finished_signal.connect(self._on_finished)
        self.worker.start()

    def _read_chip_info(self):
        port = self.port_combo.currentText().strip()
        if not port:
            QMessageBox.warning(self, "Validation", "Please select a serial port")
            return
        self._start_worker(
            "chip_info", self._params(), self.log_area, self.progress,
            [self.execute_btn, self.chip_info_btn],
        )

    def _show_safety_notice_once(self):
        if self.settings.value("saw_safety_notice") == "1":
            return
        QMessageBox.warning(
            self,
            f"Before you use {APP_NAME}",
            "Flash encryption burns eFuses. That cannot be undone.\n\n"
            "• Back up the key file. Without it you cannot update that board.\n"
            "• Flash plaintext first and confirm the firmware runs.\n"
            "• Use a board you can afford to lock while you learn the flow.\n\n"
            f"{APP_NAME} is free software, not an Espressif product.",
        )
        self.settings.setValue("saw_safety_notice", "1")

    def _confirm_permanent(self, mode):
        """Ask before any step that can burn eFuses."""
        if mode not in ("burn_key", "full", "encrypt_flash"):
            return True
        answer = QMessageBox.warning(
            self,
            "Permanent change",
            "This can burn the encryption key into the chip.\n\n"
            "Flash encryption cannot be turned off afterwards.\n"
            "Keep a copy of the key file before you continue.\n\n"
            "Continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        return answer == QMessageBox.StandardButton.Yes

    def _show_about(self):
        box = QMessageBox(self)
        box.setWindowTitle(f"About {APP_NAME}")
        box.setText(
            f"<h3>{APP_NAME} {VERSION}</h3>"
            f"<p>{TAGLINE}.</p>"
            "<p>Free under the GNU GPL v3.0. Source ships with the app.</p>"
            "<p>Not affiliated with Espressif Systems.</p>"
        )
        box.setInformativeText(
            "If this tool helped, a donation keeps it updated for new chips."
        )
        donate = box.addButton("Donate", QMessageBox.ButtonRole.ActionRole)
        site = box.addButton("Project site", QMessageBox.ButtonRole.ActionRole)
        box.addButton(QMessageBox.StandardButton.Close)
        box.exec()
        clicked = box.clickedButton()
        if clicked == donate:
            QDesktopServices.openUrl(QUrl(DONATE_URL))
        elif clicked == site:
            QDesktopServices.openUrl(QUrl(PROJECT_URL))

    def _execute_operation(self):
        mode = self._selected_mode()
        if not mode:
            QMessageBox.warning(self, "Validation", "Select an operation")
            return
        if not self._confirm_permanent(mode):
            return
        self._start_worker(
            mode, self._params(), self.log_area, self.progress,
            [self.execute_btn, self.chip_info_btn],
        )

    def _run_firmware_op(self, mode):
        if not self._confirm_permanent(mode):
            return
        self._start_worker(
            mode, self._params(), self.fw_log, self.fw_progress,
            [self.flash_plain_btn, self.encrypt_btn, self.flash_btn, self.enc_flash_btn],
        )

    def _quick_generate_key(self):
        for i, (_, m, _) in enumerate(self.op_modes):
            if m == "generate_key":
                self.op_group.button(i).setChecked(True)
                break
        self.tabs.setCurrentIndex(0)
        self._execute_operation()

    def _scan_bins(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select Arduino Build Output Folder",
        )
        if not folder:
            return
        found = scan_arduino_bins(folder, log_fn=self.fw_log.append)
        if found["bootloader"]:
            self.boot_edit.setText(found["bootloader"])
        if found["partition"]:
            self.part_edit.setText(found["partition"])
        if found["boot_app0"]:
            self.boot_app0_edit.setText(found["boot_app0"])
        if found["app"]:
            self.app_edit.setText(found["app"])

    def _clear_bins(self):
        self.boot_edit.clear()
        self.part_edit.clear()
        self.boot_app0_edit.clear()
        self.app_edit.clear()

    def _reset_settings(self):
        self.key_edit.setText(default_key_path())
        self.esptool_path.setText(str(BUNDLED_TOOL_DIR))
        self.espefuse_path.setText(str(BUNDLED_TOOL_DIR))
        self.auto_detect.setChecked(True)
        self.uart_disable.setChecked(False)
        self.jtag_disable.setChecked(False)
        self.baud_combo.setCurrentText(str(DEFAULT_FLASH_BAUD))
        self._select_chip(DEFAULT_CHIP)
        QMessageBox.information(self, "Settings", "Defaults restored.")

    def _restore_settings(self):
        # Keep paths saved under the previous AUTOPONIX product name.
        if self.settings.value("key_file") in (None, ""):
            old = QSettings("AUTOPONIX", "ESP32 Flash Encryption Tool")
            for key_name in ("key_file", "esptool_path", "espefuse_path", "flash_baud", "chip"):
                value = old.value(key_name)
                if value not in (None, ""):
                    self.settings.setValue(key_name, value)

        key = self.settings.value("key_file", default_key_path())
        # Migrate old relative / unwritable paths (e.g. "flash_encryption_key.bin"
        # resolving into Program Files after an MSI install).
        key = ensure_writable_key_path(key)
        self.key_edit.setText(key)
        esptool = self.settings.value("esptool_path", str(BUNDLED_TOOL_DIR))
        espefuse = self.settings.value("espefuse_path", str(BUNDLED_TOOL_DIR))
        self.esptool_path.setText(esptool)
        self.espefuse_path.setText(espefuse)
        self.baud_combo.setCurrentText(
            str(self.settings.value("flash_baud", DEFAULT_FLASH_BAUD))
        )
        self._select_chip(self.settings.value("chip", DEFAULT_CHIP))

    def _save_settings(self):
        self.settings.setValue("key_file", self.key_edit.text())
        self.settings.setValue("esptool_path", self.esptool_path.text())
        self.settings.setValue("espefuse_path", self.espefuse_path.text())
        self.settings.setValue("flash_baud", self.baud_combo.currentText())
        self.settings.setValue("chip", self.chip_combo.currentData())

    def _set_status(self, text, color):
        self.status_text.setText(text)
        self.status_dot.setStyleSheet(f"color: {color}; font-size: 22pt; background: transparent;")

    def _on_finished(self, success, message):
        for btn in getattr(self, "_active_buttons", []):
            btn.setEnabled(True)
        if hasattr(self, "_active_progress"):
            self._active_progress.setVisible(False)

        # Keep Key File field in sync if Generate Key relocated the path.
        if success and isinstance(message, str) and message.startswith("Key generated: "):
            actual = message[len("Key generated: "):].strip()
            if actual:
                self.key_edit.setText(actual)

        self._save_settings()

        if success:
            self._set_status("Complete", COLORS["success"])
            self.statusBar().showMessage(f"Success: {message}", 8000)
        else:
            self._set_status("Failed", COLORS["error"])
            self.statusBar().showMessage(f"Failed: {message}", 8000)
            QMessageBox.critical(self, "Operation Failed", message)

    def closeEvent(self, event):
        self._save_settings()
        super().closeEvent(event)


def _dispatch_bundled_tool():
    """
    When frozen, flash_encrypt_core re-execs this exe as `app.exe --run-tool=esptool ...`.
    Intercept that here and hand control to the bundled tool's _main() so the same
    binary doubles as esptool/espefuse/espsecure (no separate Python needed).
    """
    for i, arg in enumerate(sys.argv[1:], start=1):
        if arg.startswith("--run-tool="):
            tool = arg.split("=", 1)[1]
            sys.argv = [tool] + sys.argv[i + 1:]
            import importlib
            module = importlib.import_module(tool)
            sys.exit(module._main())


def main():
    _dispatch_bundled_tool()

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(COMPANY)
    app.setApplicationVersion(VERSION)

    font_family = load_app_fonts()
    app.setFont(QFont(font_family, 10))

    window = MainWindow(font_family)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
